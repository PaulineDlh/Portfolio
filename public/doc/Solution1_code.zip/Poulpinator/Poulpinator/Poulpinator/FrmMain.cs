﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Poulpinator_Classes_BLL;
using Poulpinator_Bdd_BLL;

namespace Poulpinator
{
    public partial class FrmMain : Form
    {
        #region All

        #region Attributs

        //crée une collection de produits
        private List<Produit> lesProduits = new List<Produit>();

        //crée une collection de catégories
        private List<Categorie> lesCategories = new List<Categorie>();

        //crée une collection de clients
        private List<Client> lesClients = new List<Client>();

        //crée une collection de commandes
        private List<Commande> lesCommandes = new List<Commande>();

        //crée un booléen qui servira si, oui ou non, le bouton modifier produit a été cliqué
        private bool btnModifierProduit;

        //crée un booléen qui servira si, oui ou non, le bouton modifier client a été cliqué
        private bool btnModifierClientt;

        //crée un booléen qui servira si, oui ou non, le bouton modifier adresse a été cliqué
        private bool btnModifierAdresseClientt;

        //crée un booléen qui servira si, oui ou non, le bouton modifier cmd a été cliqué
        private bool btnModifierCmdd;

        #endregion

        #region Constructeurs

        public FrmMain()
        {
            InitializeComponent();

            this.dataGridViewClient.AutoGenerateColumns = false;
            this.dataGridViewAdressesClient.AutoGenerateColumns = false;
            this.dataGridViewCmd.AutoGenerateColumns = false;
            this.dataGridViewContenuCmd.AutoGenerateColumns = false;
            this.dataGridViewPdt.AutoGenerateColumns = false;

            Data.UneChaineConnexionBDD = "SERVER = 127.0.0.1; DATABASE = ppe3; UID = root; PASSWORD = ";

            //connexion à la bdd
            Data.DbConnect();

            //charge les données de départ de l'application
            this.LoadData();

            //affiche le dataGridViewProduits
            AfficherDataGridViewProduits();

            //affiche le dataGridViewClients
            AfficherDataGridViewClients();

            //affiche le dataGridViewCmd
            AfficherDataGridViewCmd();

            //charge les différentes catégories 
            ChargeDesCategories();
             
            //affiche les catégories dans le comboBox
            AfficherComboBoxCategories();
        }

        #endregion


        #region Produit

        #region Méthodes 

        //affiche les infos dans le dataGridView
        private void AfficherDataGridViewProduits()
        {
            //efface le dataSource
            this.dataGridViewPdt.DataSource = null;

            //récupère les produits
            DbProduit.GetProduits();
            this.dataGridViewPdt.DataSource = this.lesProduits;

            //actualise le dataGridView
            this.dataGridViewPdt.Refresh();
        }

        //ajoute un produit
        private void AjouterProduit(Produit p)
        {
            //on ajoute un produit à la collection lesProduits
            lesProduits.Add(p);
            p.IdProduit = DbProduit.CreerProduit(p);

            //actualise le dataGridView
            this.AfficherDataGridViewProduits();

            //vide les champs quand le produit a été ajouté
            this.textBoxLibellePdt.Clear();
            this.textBoxPrixPdt.Clear();
            this.textBoxReferencePdt.Clear();
            this.richTextBoxDescriptionPdt.Clear();
            this.comboBoxCategoriePdt.SelectedIndex = -1;
            this.numericUpDownQtePdt.Value = 0;
        }

        //supprime un produit
        private void SupprimerProduit(Produit p)
        {
            //on supprime un produit de la collection lesProduits
            lesProduits.Remove(p);
            DbProduit.SupprimerProduit(p);

            //actualise le dataGridView
            this.AfficherDataGridViewProduits();
        }

        //affiche les catégories dans le comboBox
        private void AfficherComboBoxCategories()
        {
            foreach (Categorie c in this.lesCategories)
            {
                this.comboBoxCategoriePdt.Items.Add(c);
            }

            comboBoxCategoriePdt.DisplayMember = "LibelleCategorie";
        }

        //charge les catégories
        private void ChargeDesCategories()
        {
            Categorie uneCategorie = new Categorie();
            uneCategorie.SetLibelleCategorie("toto");
            uneCategorie.SetIdCategorie(1);
            this.lesCategories.Add(uneCategorie);
            //this.lesCategories = DbProduit.GetCategories();

            uneCategorie = new Categorie();
            uneCategorie.SetLibelleCategorie("titi");
            uneCategorie.SetIdCategorie(2);
            this.lesCategories.Add(uneCategorie);
            //this.lesCategories = DbProduit.GetCategories();

            uneCategorie = new Categorie();
            uneCategorie.SetLibelleCategorie("truc");
            uneCategorie.SetIdCategorie(3);
            this.lesCategories.Add(uneCategorie);
            //this.lesCategories = DbProduit.GetCategories();
        }
        #endregion

        #region Méthodes évènementielles

        //lorsqu'on clique sur "Ajouter" 
        private void btnAjouterPdt_Click(object sender, EventArgs e)
        {
            //rend le groupBox visible
            this.groupBoxPdt.Visible = true;

            //le bouton "Modifier" n'est pas actionné donc on le met à "false"
            this.btnModifierProduit = false;
        }

        //lorsqu'on clique sur "Modifier"
        private void btnModifierPdt_Click(object sender, EventArgs e)
        {
            //rend le groupbox visible
            this.groupBoxPdt.Visible = true;

            //le bouton "Modifier" est actionné donc on le met à "true"
            this.btnModifierProduit = true;

            //si l'utilisateur a bien sélectionné une ligne
            if (this.dataGridViewPdt.SelectedRows.Count > 0)
            {
                //récupère un produit
                Produit unProduit = this.dataGridViewPdt.CurrentRow.DataBoundItem as Produit;

                //remplit le formulaire avec les infos du produit sélectionné
                richTextBoxDescriptionPdt.Text = unProduit.GetDescritionProduit();
                textBoxLibellePdt.Text = unProduit.GetLibelleProduit();
                textBoxPrixPdt.Text = unProduit.GetPrixUnitaireProduit().ToString();
                numericUpDownQtePdt.Text = unProduit.GetQuantiteProduit().ToString();
                textBoxReferencePdt.Text = unProduit.GetReferenceProduit();
                comboBoxCategoriePdt.Text = unProduit.GetLaCategorie().GetLibelleCategorie();
            }
        }

        //lorsqu'on clique sur "OK" dans le groupBox
        private void btnOkPdt_Click(object sender, EventArgs e)
        {
            //déclare un produit
            Produit unProduit;

            //si on appuie sur le bouton "Modifier"
            if (this.btnModifierProduit)
            {
                //si l'utilisateur a bien sélectionné au moins une ligne
                if (this.dataGridViewPdt.SelectedRows.Count > 0)
                {
                    //récupère un produit
                    unProduit = this.dataGridViewPdt.CurrentRow.DataBoundItem as Produit;
                }
                else
                {
                    //instancie un nouveau produit
                    unProduit = new Produit();
                }
            }
            else
            {
                //déclare et instancie un nouvel objet de type Produit
                unProduit = new Produit();
            }
            //création d'une variable pour convertir le textbox du prix en int
            double prixEnDouble = 0;
            Double.TryParse(textBoxPrixPdt.Text, out prixEnDouble);

            //création d'une variable pour convertir le numericUpDown de la qté en int
            int qteEnInt = 0;
            Int32.TryParse(numericUpDownQtePdt.Text, out qteEnInt);

            //récupère les infos du produit
            unProduit.SetDescriptionProduit(richTextBoxDescriptionPdt.Text);
            unProduit.SetLibelleProduit(textBoxLibellePdt.Text);
            unProduit.SetPrixUnitaireProduit(prixEnDouble);
            unProduit.SetQuantiteProduit(qteEnInt);
            unProduit.SetReferenceProduit(textBoxReferencePdt.Text);
            unProduit.SetLaCategorie(comboBoxCategoriePdt.SelectedItem as Categorie);

            //affiche les infos du produit 
            DialogResult msgBox;
            string message = "Les informations du produit";
            message += "\n" + "Libellé : " + unProduit.GetLibelleProduit();
            message += "\n" + "Prix : " + unProduit.GetPrixUnitaireProduit();
            message += "\n" + "Quantité : " + unProduit.GetQuantiteProduit();
            message += "\n" + "Référence : " + unProduit.GetReferenceProduit();
            message += "\n" + "Description : " + unProduit.GetDescritionProduit();
            //pour les catégories
            if (unProduit.GetLaCategorie() == null)
            {
                message += "\n" + "Catégorie : " + "Aucune";
            }
            else
            {
                message += "\n" + "Catégorie : " + unProduit.GetLaCategorie().GetLibelleCategorie();
            }

            //message informant l'utilisateur avec les infos du produit
            msgBox = MessageBox.Show(message, "Produit", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            //si l'utilisateur clique sur "OK et si il avait cliqué sur "Ajouter" et non "Modifier"
            if (msgBox == DialogResult.OK)
            {
                if (this.btnModifierProduit == false)
                {
                    //appelle la méthode pour ajouter l'objet produit
                    this.AjouterProduit(unProduit);
                    unProduit.IdProduit = DbProduit.CreerProduit(unProduit);
                } else
                {
                    DbProduit.UpdateProduit(unProduit);
                }
            }
            //actualise le dataGridView
            this.AfficherDataGridViewProduits();

            //vide les champs quand le produit a été modifié
            this.textBoxLibellePdt.Clear();
            this.textBoxPrixPdt.Clear();
            this.textBoxReferencePdt.Clear();
            this.richTextBoxDescriptionPdt.Clear();
            this.comboBoxCategoriePdt.SelectedIndex = -1;
            this.numericUpDownQtePdt.Value = 0;
        }

        //si on clique sur un produit dans le dataGridView puis sur "Supprimer"
        private void btnSupprimerPdt_Click(object sender, EventArgs e)
        {
            //si l'utilisateur a bien sélectionné au moins une ligne
            if (this.dataGridViewPdt.SelectedRows.Count > 0)
            {
                DialogResult result;

                //déclare un produit
                Produit unProduit;

                //récupère un produit
                unProduit = this.dataGridViewPdt.CurrentRow.DataBoundItem as Produit;

                //message pour demander confirmation à l'utilisateur
                result = MessageBox.Show("Êtes-vous sur de vouloir supprimer ce produit ?", "Supprimer", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (result == DialogResult.OK)
                {
                    //si l'utilisateur confirme, alors le produit est bien supprimé
                    this.SupprimerProduit(unProduit);
                }
            }
        }

        //lorsqu'on clique sur "Annuler" parce qu'on a finalement changé d'avis, remet les champs vides
        private void btnAnnulerPdt_Click(object sender, EventArgs e)
        {
            this.textBoxLibellePdt.Clear();
            this.textBoxPrixPdt.Clear();
            this.textBoxReferencePdt.Clear();
            this.richTextBoxDescriptionPdt.Clear();
        }

        #endregion

        #endregion


        #region Client

        #region Méthodes

        //affiche les infos dans le dataGridView
        private void AfficherDataGridViewClients()
        {
            //efface le dataSource
            this.dataGridViewClient.DataSource = null;

            //récupère les clients
            DbClient.GetClients();
            this.dataGridViewClient.DataSource = this.lesClients;

            //actualise le dataGridView
            this.dataGridViewClient.Refresh();
        }

        //ajoute un client à la collection lesClients
        private void AjouterClient(Client c)
        {
            //on ajoute un client à la collection lesClients
            lesClients.Add(c);
            c.IdClient = DbClient.CreerClient(c);

            //actualise le dataGridView
            this.AfficherDataGridViewClients();

            //vide les champs quand le client a été ajouté
            this.textBoxClientNom.Clear();
            this.textBoxClientPrenom.Clear();
        }

        //supprime un client de la collection lesClients
        private void SupprimerClient(Client c)
        {
            //on supprime un client de la collection lesClients
            c.Actif = 0;
            DbClient.DesactiverClient(c);

            //actualise le dataGridView
            this.AfficherDataGridViewClients();
        }

        #endregion

        #region Méthodes évènementielles

        //lorsqu'on clique sur "Annuler", vide les infos du client tapées dans le textBox
        private void btnClientAnnuler_Click(object sender, EventArgs e)
        {
            this.textBoxClientNom.Clear();
            this.textBoxClientPrenom.Clear();
        }

        //lorsqu'on clique sur "OK"
        private void btnClientOK_Click(object sender, EventArgs e)
        {
            //crée un nouveau client
            Client unClient;

            //si on avait cliqué sur "Modifier"
            if (this.btnModifierClientt)
            {

                //si l'utilisateur a bien sélectionné au moins une ligne
                if (this.dataGridViewClient.SelectedRows.Count > 0)
                {
                    //récupère un client
                    unClient = this.dataGridViewClient.CurrentRow.DataBoundItem as Client;
                }
                else
                {
                    //instancie un nouveau client
                    unClient = new Client();
                }
            } else
            {
                //déclare et instancie un nouvel objet de type Client
                unClient = new Client();
            }

            //récupère les infos du client
            unClient.SetNomClient(textBoxClientNom.Text);
            unClient.SetPrenomClient(textBoxClientPrenom.Text);

            //affiche les infos du client
            DialogResult msgBox;
            string message = "Les informations du client :";
            message += "\n" + "Nom : " + unClient.GetNomClient();
            message += "\n" + "Prénom : " + unClient.GetPrenomClient();

            //message informant l'utilisateur avec les infos du client
            msgBox = MessageBox.Show(message, "Client", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            //si l'utilisateur confirme les infos du client
            if (msgBox == DialogResult.OK)
            {
                //si le bouton "Modifier" n'a pas été cliqué
                if (this.btnModifierClientt == false)
                {
                    //appelle la méthode pour ajouter l'objet client
                    this.AjouterClient(unClient);
                    unClient.IdClient = DbClient.CreerClient(unClient);
                    this.dataGridViewClient.Refresh();
                } else
                {
                    DbClient.UpdateClient(unClient);
                }
            }

            //actualise le dataGridView
            this.AfficherDataGridViewClients();

            //vide les champs quand le client a été modifié
            this.textBoxClientNom.Clear();
            this.textBoxClientPrenom.Clear();
        }

        //lorsqu'on clique sur "Ajouter"
        private void btnAjouterClient_Click(object sender, EventArgs e)
        {
            //rend visible le groupBoxClient
            this.groupBoxClient.Visible = true;

            //on clique sur "Ajouter" et non "Modifier"
            this.btnModifierClientt = false;
        }

        //lorsqu'on clique sur "Modifier"
        private void btnModifierClient_Click(object sender, EventArgs e)
        {
            //rend le groupBox visible
            this.groupBoxClient.Visible = true;

            //confirme l'utilisation du bouton "Modifier"
            this.btnModifierClientt = true;

            //si l'utilisateur a bien sélectionné une ligne
            if (this.dataGridViewClient.SelectedRows.Count > 0)
            {
                //récupère un client
                Client unClient = this.dataGridViewClient.CurrentRow.DataBoundItem as Client;

                //remplit le formulaire avec les infos du client sélectionné
                textBoxClientNom.Text = unClient.GetNomClient();
                textBoxClientPrenom.Text = unClient.GetPrenomClient();
            }
        }

        //lorsqu'on clique sur "Supprimer"
        private void btnSupprimerClient_Click(object sender, EventArgs e)
        {

            //si l'utilisateur a bien sélectionné au moins une ligne
            if (this.dataGridViewClient.SelectedRows.Count > 0)
            {
                DialogResult result;

                //déclare un client
                Client unClient;

                //récupère un client
                unClient = this.dataGridViewClient.CurrentRow.DataBoundItem as Client;

                //message de confirmation
                result = MessageBox.Show("Êtes-vous sur de vouloir supprimer ce client ?", "Supprimer", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (result == DialogResult.OK)
                {
                    //si l'utilisateur confirme, alors le client est bien supprimé
                    this.SupprimerClient(unClient);
                }
            }
        }

        //quand on sélectionne un client dans le dataGridView
        private void dataGridViewClient_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dataGridViewClient.SelectedRows.Count > 0)
            {
                //récupère un client
                Client unClient = this.dataGridViewClient.CurrentRow.DataBoundItem as Client;
                unClient.SetLesAdresse(DbClient.GetAdresses(unClient));
                AfficherDataGridViewAdressesClient(unClient);
            } else
            {
                this.dataGridViewAdressesClient.DataSource = null;
                this.dataGridViewAdressesClient.Refresh();
            }
        }


        #endregion

        #endregion


        #region Adresse

        #region Méthodes

        //affiche les infos dans le dataGridView
        private void AfficherDataGridViewAdressesClient(Client unClient)
        {
            //efface le dataSource
            this.dataGridViewAdressesClient.DataSource = null;

            //récupère les adresses du client
            DbClient.GetAdresses(unClient);
            this.dataGridViewAdressesClient.DataSource = unClient.GetLesAdresses();

            //actualise le dataGridView
            this.dataGridViewAdressesClient.Refresh();
        }

        //ajoute une adresse 
        private void AjouterAdresse(Adresse a)
        {
            //on ajoute une adresse à la collection lesAdresses
            a.GetClient().GetLesAdresses().Add(a);
            a.IdAdresse = DbClient.CreerAdresse(a);

            //actualise le dataGridView
            this.AfficherDataGridViewAdressesClient(a.GetClient());

            //vide les champs quand l'adresse a été ajoutée
            this.textBoxModifAdresse1Client.Clear();
            this.textBoxModifAdresse2Client.Clear();
            this.textBoxModifCPClient.Clear();
            this.textBoxModifVilleClient.Clear();
        }

        //supprime une adresse
        private void SupprimerAdresse(Adresse a)
        {
            //on supprime une adresse de la collection lesAdresses
            a.GetClient().GetLesAdresses().Remove(a);
            DbClient.SupprimerAdresse(a);

            //actualise le dataGridView
            this.AfficherDataGridViewAdressesClient(a.GetClient());
        }

        #endregion

        #region Méthodes évènementielles

        //lorsqu'on clique sur "Ajouter"
        private void btnAjouterAdresseClient_Click(object sender, EventArgs e)
        {
            //rend visible le groupBoxA
            this.groupBoxModifAdresseClient.Visible = true;

            //on a cliqué sur "Ajouter" et non "Modifier"
            this.btnModifierAdresseClientt = false;
        }

        //lorsqu'on clique sur le bouton "Modifier"
        private void btnModifierAdresseClient_Click(object sender, EventArgs e)
        {
            //rend le groupBox visible
            this.groupBoxModifAdresseClient.Visible = true;

            //confirme que l'on souhaite une modification
            this.btnModifierAdresseClientt = true;

            //si l'utilisateur a bien sélectionné au moins une ligne
            if (this.dataGridViewAdressesClient.SelectedRows.Count > 0)
            {
                //récupère une adresse
                Adresse uneAdresse = this.dataGridViewAdressesClient.CurrentRow.DataBoundItem as Adresse;

                //remplit le formulaire avec les infos de l'adresse sélectionnée
                textBoxModifAdresse1Client.Text = uneAdresse.GetVoie();
                textBoxModifAdresse2Client.Text = uneAdresse.GetComplement();
                textBoxModifCPClient.Text = uneAdresse.GetCodePostal();
                textBoxModifVilleClient.Text = uneAdresse.GetVille();
            }
        }

        //lorsqu'on clique sur "Supprimer"
        private void btnSupprimerAdresseClient_Click(object sender, EventArgs e)
        {
            //si l'utilisateur a bien sélectionné au moins une ligne
            if (this.dataGridViewAdressesClient.SelectedRows.Count > 0)
            {
                DialogResult result;

                Adresse uneAdresse;

                //récupère un client
                uneAdresse = this.dataGridViewAdressesClient.CurrentRow.DataBoundItem as Adresse;

                //message de confirmation
                result = MessageBox.Show("Êtes-vous sur de vouloir supprimer cette adresse ?", "Supprimer", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

                if (result == DialogResult.OK)
                {
                    //si l'utilisateur confirme, alors l'adresse est bien supprimée
                    this.SupprimerAdresse(uneAdresse);
                }
            }
        }

        //lorsqu'on souhaite annuler les modifications, vide les champs
        private void btnAnnulerModifAdresseClient_Click(object sender, EventArgs e)
        {
            this.textBoxModifAdresse1Client.Clear();
            this.textBoxModifAdresse2Client.Clear();
            this.textBoxModifCPClient.Clear();
            this.textBoxModifVilleClient.Clear();
        }

        //lorsqu'on clique sur "OK"
        private void btnAppliquerModifAdresseClient_Click(object sender, EventArgs e)
        {
            //crée une nouvelle adresse
            Adresse uneAdresse;

            //récupère le client
            Client unClient = this.dataGridViewClient.CurrentRow.DataBoundItem as Client;

            //si on a cliqué sur "Modifier"
            if (this.btnModifierAdresseClientt)
            {
                //si l'utilisateur a bien sélectionné au moins une ligne
                if(this.dataGridViewAdressesClient.SelectedRows.Count > 0)
                {
                    //récupère une adresse
                    uneAdresse = this.dataGridViewAdressesClient.CurrentRow.DataBoundItem as Adresse;
                } else
                {
                    //instancie une adresse
                    uneAdresse = new Adresse();
                }
            } else
            {
                //déclare et instancie un nouvel objet de type Adresse
                uneAdresse = new Adresse();
            }

            //récupère les infos de l'adresse
            uneAdresse.SetVoie(textBoxModifAdresse1Client.Text);
            uneAdresse.SetComplement(textBoxModifAdresse2Client.Text);
            uneAdresse.SetCodePostal(textBoxModifCPClient.Text);
            uneAdresse.SetVille(textBoxModifVilleClient.Text);
            uneAdresse.SetClient(unClient);
    
            //affiche les infos de l'adresse
            DialogResult msgBox;
            string message = "Les informations de l'adresse :";
            message += "\n" + "Voie : " + uneAdresse.GetVoie();
            message += "\n" + "Complément : " + uneAdresse.GetComplement();
            message += "\n" + "Code postal : " + uneAdresse.GetCodePostal();
            message += "\n" + "Ville : " + uneAdresse.GetVille();

            //message contenant les infos de l'adresse
            msgBox = MessageBox.Show(message, "Adresse", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            //si l'utilisateur confirme
            if (msgBox == DialogResult.OK)
            {
                //s'il n'a pas cliqué sur "Modifier", ajoute une nouvelle adresse
                if (this.btnModifierAdresseClientt == false)
                {
                    //appelle la méthode pour ajouter l'objet adresse
                    this.AjouterAdresse(uneAdresse);
                    uneAdresse.IdAdresse = DbClient.CreerAdresse(uneAdresse);
                } else
                {
                    DbClient.UpdateAdresse(uneAdresse);
                }
            }

            //actualise le dataGridView
            this.AfficherDataGridViewAdressesClient(uneAdresse.GetClient());

            //vide les champs quand l'adresse a été modifiée
            this.textBoxModifAdresse1Client.Clear();
            this.textBoxModifAdresse2Client.Clear();
            this.textBoxModifCPClient.Clear();
            this.textBoxModifVilleClient.Clear();
        }

        #endregion

        #endregion


        #region Commande

        #region Méthodes

        //affiche les infos dans le dataGridView
        private void AfficherDataGridViewCmd()
        {
            //efface le dataSource
            this.dataGridViewCmd.DataSource = null;

            //récupère les commandes
            this.lesCommandes = DbCommande.GetCommandes();
            this.dataGridViewCmd.DataSource = this.lesCommandes;

            //actualise le dataGridView
            this.dataGridViewCmd.Refresh();
        }

        #endregion

        #region Méthodes évènementielles

        //quand on clique sur le bouton "Modifier"
        private void btnModifStatut_Click(object sender, EventArgs e)
        {
            //rend le groupbox visible
            this.groupBoxModifStatutCmd.Visible = true;

            //le bouton "Modifier" est actionné donc on le met à "true"
            this.btnModifierCmdd = true;

            //si l'utilisateur a bien sélectionné au moins une ligne
            if (this.dataGridViewCmd.SelectedRows.Count > 0)
            {
                //récupère un produit
                Commande uneCommande = this.dataGridViewCmd.CurrentRow.DataBoundItem as Commande;

                //remplit le formulaire avec le statut de la commande sélectionnée
                comboBoxStatutCmd.Text = uneCommande.GetStatutCommande(); 
            }
        }

        //quand on approuve le changement de statut dans le comboBox
        private void btnModifierStatutCmd_Click(object sender, EventArgs e)
        {
            //déclare une commande
            Commande uneCommande;

            //si l'utilisateur a bien sélectionné au moins une ligne
            if (this.dataGridViewCmd.SelectedRows.Count > 0)
            {
                //récupère une commande
                uneCommande = this.dataGridViewCmd.CurrentRow.DataBoundItem as Commande;

                //récupère le statut de la commande
                uneCommande.SetStatutCommande(comboBoxStatutCmd.SelectedItem as string);

                //affiche les infos du produit 
                DialogResult msgBox;
                string message = "Le statut de la commande :";
                message += "\n" + "Statut : " + uneCommande.GetStatutCommande();

                //message informant l'utilisateur avec le statut de la commande
                msgBox = MessageBox.Show(message, "Commande :", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

                //actualise le dataGridView
                this.AfficherDataGridViewCmd();

                //vide le champs quand le statut a été modifié
                this.comboBoxStatutCmd.SelectedIndex = -1;
            }
        }

        //quand on sélectionne une commande dans le dataGridView
        private void dataGridViewCmd_SelectionChanged(object sender, EventArgs e)
        {
            if (this.dataGridViewCmd.SelectedRows.Count > 0)
            {
                //récupère une commande
                Commande uneCommande = this.dataGridViewCmd.CurrentRow.DataBoundItem as Commande;
                AfficherDataGridViewContenuCmd(uneCommande);
            }
            else
            {
                this.dataGridViewContenuCmd.DataSource = null;
                this.dataGridViewContenuCmd.Refresh();
            }
        }


        #endregion

        #endregion

        #region ContenuCommande

        #region Méthodes

        //affiche les infos dans le dataGridView
        private void AfficherDataGridViewContenuCmd(Commande uneCommande)
        {
            //efface le dataSource
            this.dataGridViewContenuCmd.DataSource = null;

            //récupère le contenu de la commande
            uneCommande.SetContenuCommandes(DbCommande.GetContenuCommandes(uneCommande));
            this.dataGridViewContenuCmd.DataSource = uneCommande.GetContenuCommandes();

            //actualise le dataGridView
            this.dataGridViewContenuCmd.Refresh();
        }

        #endregion

        #endregion


        private void LoadData()
        {
            lesProduits = DbProduit.GetProduits();

            lesCommandes = DbCommande.GetCommandes();

            lesClients = DbClient.GetClients();
        }

        #endregion

        private void FrmMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            Data.DbDisconnect();
        }
    }
}
