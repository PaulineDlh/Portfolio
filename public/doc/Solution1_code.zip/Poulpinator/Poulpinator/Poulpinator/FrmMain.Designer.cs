﻿namespace Poulpinator
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabClients = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelClient = new System.Windows.Forms.TableLayoutPanel();
            this.panelClient = new System.Windows.Forms.Panel();
            this.labelLesClients = new System.Windows.Forms.Label();
            this.panelBtnClients = new System.Windows.Forms.Panel();
            this.btnSupprimerClient = new System.Windows.Forms.Button();
            this.btnModifierClient = new System.Windows.Forms.Button();
            this.btnAjouterClient = new System.Windows.Forms.Button();
            this.dataGridViewClient = new System.Windows.Forms.DataGridView();
            this.NumeroClient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomClient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrenomClient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.actif = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelAdressesClient = new System.Windows.Forms.Panel();
            this.dataGridViewAdressesClient = new System.Windows.Forms.DataGridView();
            this.idAdresse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.voie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.complement = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codePostal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ville = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSupprimerAdresseClient = new System.Windows.Forms.Button();
            this.btnModifierAdresseClient = new System.Windows.Forms.Button();
            this.btnAjouterAdresseClient = new System.Windows.Forms.Button();
            this.labelAdressesClient = new System.Windows.Forms.Label();
            this.panelModifAdresseClient = new System.Windows.Forms.Panel();
            this.groupBoxModifAdresseClient = new System.Windows.Forms.GroupBox();
            this.btnAnnulerModifAdresseClient = new System.Windows.Forms.Button();
            this.btnAppliquerModifAdresseClient = new System.Windows.Forms.Button();
            this.textBoxModifVilleClient = new System.Windows.Forms.TextBox();
            this.labelModifVilleClient = new System.Windows.Forms.Label();
            this.textBoxModifCPClient = new System.Windows.Forms.TextBox();
            this.labelModifCPClient = new System.Windows.Forms.Label();
            this.textBoxModifAdresse2Client = new System.Windows.Forms.TextBox();
            this.textBoxModifAdresse1Client = new System.Windows.Forms.TextBox();
            this.labelModifAdresse1Client = new System.Windows.Forms.Label();
            this.panelClientEtRecherche = new System.Windows.Forms.Panel();
            this.groupBoxClient = new System.Windows.Forms.GroupBox();
            this.btnClientAnnuler = new System.Windows.Forms.Button();
            this.btnClientOK = new System.Windows.Forms.Button();
            this.textBoxClientPrenom = new System.Windows.Forms.TextBox();
            this.textBoxClientNom = new System.Windows.Forms.TextBox();
            this.labelClientPrenom = new System.Windows.Forms.Label();
            this.labelClientNom = new System.Windows.Forms.Label();
            this.tabCommandes = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelCmd = new System.Windows.Forms.TableLayoutPanel();
            this.panelCmd = new System.Windows.Forms.Panel();
            this.labelCmd = new System.Windows.Forms.Label();
            this.dataGridViewCmd = new System.Windows.Forms.DataGridView();
            this.NumeroCmd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idClient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateCmd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fraisPort = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalCmd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statutCmd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelBtnCmd = new System.Windows.Forms.Panel();
            this.btnModifStatut = new System.Windows.Forms.Button();
            this.panelContenuCmd = new System.Windows.Forms.Panel();
            this.dataGridViewContenuCmd = new System.Windows.Forms.DataGridView();
            this.labelContenuCmd = new System.Windows.Forms.Label();
            this.groupBoxModifStatutCmd = new System.Windows.Forms.GroupBox();
            this.comboBoxStatutCmd = new System.Windows.Forms.ComboBox();
            this.btnModifierStatutCmd = new System.Windows.Forms.Button();
            this.labelStatutCmd = new System.Windows.Forms.Label();
            this.tabProduits = new System.Windows.Forms.TabPage();
            this.tableLayoutPanelPdt = new System.Windows.Forms.TableLayoutPanel();
            this.groupBoxPdt = new System.Windows.Forms.GroupBox();
            this.comboBoxCategoriePdt = new System.Windows.Forms.ComboBox();
            this.labelCategoriePdt = new System.Windows.Forms.Label();
            this.btnAnnulerPdt = new System.Windows.Forms.Button();
            this.richTextBoxDescriptionPdt = new System.Windows.Forms.RichTextBox();
            this.numericUpDownQtePdt = new System.Windows.Forms.NumericUpDown();
            this.btnOkPdt = new System.Windows.Forms.Button();
            this.textBoxReferencePdt = new System.Windows.Forms.TextBox();
            this.textBoxPrixPdt = new System.Windows.Forms.TextBox();
            this.textBoxLibellePdt = new System.Windows.Forms.TextBox();
            this.labelDescriptionPdt = new System.Windows.Forms.Label();
            this.labelQtePdt = new System.Windows.Forms.Label();
            this.labelReferencePdt = new System.Windows.Forms.Label();
            this.labelPrixUnitairePdt = new System.Windows.Forms.Label();
            this.labelLibellePdt = new System.Windows.Forms.Label();
            this.panelPdt = new System.Windows.Forms.Panel();
            this.labelLesProduits = new System.Windows.Forms.Label();
            this.dataGridViewPdt = new System.Windows.Forms.DataGridView();
            this.idPdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.libellePdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prixUnitairePdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtePdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.referencePdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoriePdt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panelBtnPdt = new System.Windows.Forms.Panel();
            this.btnSupprimerPdt = new System.Windows.Forms.Button();
            this.btnModifierPdt = new System.Windows.Forms.Button();
            this.btnAjouterPdt = new System.Windows.Forms.Button();
            this.idContenuCmd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idProduit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qteProduit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prixUnitaire = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl.SuspendLayout();
            this.tabClients.SuspendLayout();
            this.tableLayoutPanelClient.SuspendLayout();
            this.panelClient.SuspendLayout();
            this.panelBtnClients.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).BeginInit();
            this.panelAdressesClient.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdressesClient)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelModifAdresseClient.SuspendLayout();
            this.groupBoxModifAdresseClient.SuspendLayout();
            this.panelClientEtRecherche.SuspendLayout();
            this.groupBoxClient.SuspendLayout();
            this.tabCommandes.SuspendLayout();
            this.tableLayoutPanelCmd.SuspendLayout();
            this.panelCmd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCmd)).BeginInit();
            this.panelBtnCmd.SuspendLayout();
            this.panelContenuCmd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewContenuCmd)).BeginInit();
            this.groupBoxModifStatutCmd.SuspendLayout();
            this.tabProduits.SuspendLayout();
            this.tableLayoutPanelPdt.SuspendLayout();
            this.groupBoxPdt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQtePdt)).BeginInit();
            this.panelPdt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPdt)).BeginInit();
            this.panelBtnPdt.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl.Controls.Add(this.tabClients);
            this.tabControl.Controls.Add(this.tabCommandes);
            this.tabControl.Controls.Add(this.tabProduits);
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(1344, 782);
            this.tabControl.TabIndex = 0;
            // 
            // tabClients
            // 
            this.tabClients.Controls.Add(this.tableLayoutPanelClient);
            this.tabClients.Location = new System.Drawing.Point(4, 25);
            this.tabClients.Name = "tabClients";
            this.tabClients.Padding = new System.Windows.Forms.Padding(3);
            this.tabClients.Size = new System.Drawing.Size(1336, 753);
            this.tabClients.TabIndex = 0;
            this.tabClients.Text = "Clients";
            this.tabClients.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelClient
            // 
            this.tableLayoutPanelClient.ColumnCount = 2;
            this.tableLayoutPanelClient.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelClient.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelClient.Controls.Add(this.panelClient, 1, 0);
            this.tableLayoutPanelClient.Controls.Add(this.panelAdressesClient, 1, 1);
            this.tableLayoutPanelClient.Controls.Add(this.panelModifAdresseClient, 0, 1);
            this.tableLayoutPanelClient.Controls.Add(this.panelClientEtRecherche, 0, 0);
            this.tableLayoutPanelClient.Location = new System.Drawing.Point(17, 14);
            this.tableLayoutPanelClient.Name = "tableLayoutPanelClient";
            this.tableLayoutPanelClient.RowCount = 2;
            this.tableLayoutPanelClient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelClient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelClient.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelClient.Size = new System.Drawing.Size(1255, 733);
            this.tableLayoutPanelClient.TabIndex = 0;
            // 
            // panelClient
            // 
            this.panelClient.Controls.Add(this.labelLesClients);
            this.panelClient.Controls.Add(this.panelBtnClients);
            this.panelClient.Controls.Add(this.dataGridViewClient);
            this.panelClient.Location = new System.Drawing.Point(630, 3);
            this.panelClient.Name = "panelClient";
            this.panelClient.Size = new System.Drawing.Size(622, 360);
            this.panelClient.TabIndex = 4;
            // 
            // labelLesClients
            // 
            this.labelLesClients.AutoSize = true;
            this.labelLesClients.Location = new System.Drawing.Point(2, 5);
            this.labelLesClients.Name = "labelLesClients";
            this.labelLesClients.Size = new System.Drawing.Size(83, 17);
            this.labelLesClients.TabIndex = 3;
            this.labelLesClients.Text = "Les clients :";
            // 
            // panelBtnClients
            // 
            this.panelBtnClients.Controls.Add(this.btnSupprimerClient);
            this.panelBtnClients.Controls.Add(this.btnModifierClient);
            this.panelBtnClients.Controls.Add(this.btnAjouterClient);
            this.panelBtnClients.Location = new System.Drawing.Point(159, 4);
            this.panelBtnClients.Name = "panelBtnClients";
            this.panelBtnClients.Size = new System.Drawing.Size(306, 40);
            this.panelBtnClients.TabIndex = 3;
            // 
            // btnSupprimerClient
            // 
            this.btnSupprimerClient.Location = new System.Drawing.Point(212, 2);
            this.btnSupprimerClient.Name = "btnSupprimerClient";
            this.btnSupprimerClient.Size = new System.Drawing.Size(93, 37);
            this.btnSupprimerClient.TabIndex = 2;
            this.btnSupprimerClient.Text = "Désactiver";
            this.btnSupprimerClient.UseVisualStyleBackColor = true;
            this.btnSupprimerClient.Click += new System.EventHandler(this.btnSupprimerClient_Click);
            // 
            // btnModifierClient
            // 
            this.btnModifierClient.Location = new System.Drawing.Point(106, 1);
            this.btnModifierClient.Name = "btnModifierClient";
            this.btnModifierClient.Size = new System.Drawing.Size(100, 40);
            this.btnModifierClient.TabIndex = 1;
            this.btnModifierClient.Text = "Modifier";
            this.btnModifierClient.UseVisualStyleBackColor = true;
            this.btnModifierClient.Click += new System.EventHandler(this.btnModifierClient_Click);
            // 
            // btnAjouterClient
            // 
            this.btnAjouterClient.Location = new System.Drawing.Point(1, 0);
            this.btnAjouterClient.Name = "btnAjouterClient";
            this.btnAjouterClient.Size = new System.Drawing.Size(97, 40);
            this.btnAjouterClient.TabIndex = 0;
            this.btnAjouterClient.Text = "Ajouter";
            this.btnAjouterClient.UseVisualStyleBackColor = true;
            this.btnAjouterClient.Click += new System.EventHandler(this.btnAjouterClient_Click);
            // 
            // dataGridViewClient
            // 
            this.dataGridViewClient.AllowUserToAddRows = false;
            this.dataGridViewClient.AllowUserToDeleteRows = false;
            this.dataGridViewClient.AllowUserToResizeColumns = false;
            this.dataGridViewClient.AllowUserToResizeRows = false;
            this.dataGridViewClient.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClient.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NumeroClient,
            this.NomClient,
            this.PrenomClient,
            this.actif});
            this.dataGridViewClient.Location = new System.Drawing.Point(6, 46);
            this.dataGridViewClient.MultiSelect = false;
            this.dataGridViewClient.Name = "dataGridViewClient";
            this.dataGridViewClient.ReadOnly = true;
            this.dataGridViewClient.RowTemplate.Height = 24;
            this.dataGridViewClient.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewClient.Size = new System.Drawing.Size(622, 311);
            this.dataGridViewClient.TabIndex = 3;
            this.dataGridViewClient.SelectionChanged += new System.EventHandler(this.dataGridViewClient_SelectionChanged);
            // 
            // NumeroClient
            // 
            this.NumeroClient.DataPropertyName = "IdClient";
            this.NumeroClient.HeaderText = "Id client";
            this.NumeroClient.Name = "NumeroClient";
            this.NumeroClient.ReadOnly = true;
            // 
            // NomClient
            // 
            this.NomClient.DataPropertyName = "NomClient";
            this.NomClient.HeaderText = "Nom";
            this.NomClient.Name = "NomClient";
            this.NomClient.ReadOnly = true;
            // 
            // PrenomClient
            // 
            this.PrenomClient.DataPropertyName = "PrenomClient";
            this.PrenomClient.HeaderText = "Prénom";
            this.PrenomClient.Name = "PrenomClient";
            this.PrenomClient.ReadOnly = true;
            // 
            // actif
            // 
            this.actif.DataPropertyName = "Actif";
            this.actif.HeaderText = "Actif";
            this.actif.Name = "actif";
            this.actif.ReadOnly = true;
            // 
            // panelAdressesClient
            // 
            this.panelAdressesClient.Controls.Add(this.dataGridViewAdressesClient);
            this.panelAdressesClient.Controls.Add(this.panel1);
            this.panelAdressesClient.Controls.Add(this.labelAdressesClient);
            this.panelAdressesClient.Location = new System.Drawing.Point(630, 369);
            this.panelAdressesClient.Name = "panelAdressesClient";
            this.panelAdressesClient.Size = new System.Drawing.Size(622, 361);
            this.panelAdressesClient.TabIndex = 5;
            // 
            // dataGridViewAdressesClient
            // 
            this.dataGridViewAdressesClient.AllowUserToAddRows = false;
            this.dataGridViewAdressesClient.AllowUserToDeleteRows = false;
            this.dataGridViewAdressesClient.AllowUserToResizeColumns = false;
            this.dataGridViewAdressesClient.AllowUserToResizeRows = false;
            this.dataGridViewAdressesClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAdressesClient.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idAdresse,
            this.voie,
            this.complement,
            this.codePostal,
            this.ville});
            this.dataGridViewAdressesClient.Location = new System.Drawing.Point(5, 52);
            this.dataGridViewAdressesClient.MultiSelect = false;
            this.dataGridViewAdressesClient.Name = "dataGridViewAdressesClient";
            this.dataGridViewAdressesClient.ReadOnly = true;
            this.dataGridViewAdressesClient.RowTemplate.Height = 24;
            this.dataGridViewAdressesClient.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAdressesClient.Size = new System.Drawing.Size(613, 288);
            this.dataGridViewAdressesClient.TabIndex = 2;
            // 
            // idAdresse
            // 
            this.idAdresse.DataPropertyName = "IdAdresse";
            this.idAdresse.HeaderText = "Id adresse";
            this.idAdresse.Name = "idAdresse";
            this.idAdresse.ReadOnly = true;
            // 
            // voie
            // 
            this.voie.DataPropertyName = "Voie";
            this.voie.HeaderText = "Voie";
            this.voie.Name = "voie";
            this.voie.ReadOnly = true;
            // 
            // complement
            // 
            this.complement.DataPropertyName = "Complement";
            this.complement.HeaderText = "Complément";
            this.complement.Name = "complement";
            this.complement.ReadOnly = true;
            // 
            // codePostal
            // 
            this.codePostal.DataPropertyName = "CodePostal";
            this.codePostal.HeaderText = "Code postal";
            this.codePostal.Name = "codePostal";
            this.codePostal.ReadOnly = true;
            // 
            // ville
            // 
            this.ville.DataPropertyName = "Ville";
            this.ville.HeaderText = "Ville";
            this.ville.Name = "ville";
            this.ville.ReadOnly = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnSupprimerAdresseClient);
            this.panel1.Controls.Add(this.btnModifierAdresseClient);
            this.panel1.Controls.Add(this.btnAjouterAdresseClient);
            this.panel1.Location = new System.Drawing.Point(167, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 45);
            this.panel1.TabIndex = 1;
            // 
            // btnSupprimerAdresseClient
            // 
            this.btnSupprimerAdresseClient.Location = new System.Drawing.Point(212, 5);
            this.btnSupprimerAdresseClient.Name = "btnSupprimerAdresseClient";
            this.btnSupprimerAdresseClient.Size = new System.Drawing.Size(93, 37);
            this.btnSupprimerAdresseClient.TabIndex = 3;
            this.btnSupprimerAdresseClient.Text = "Supprimer";
            this.btnSupprimerAdresseClient.UseVisualStyleBackColor = true;
            this.btnSupprimerAdresseClient.Click += new System.EventHandler(this.btnSupprimerAdresseClient_Click);
            // 
            // btnModifierAdresseClient
            // 
            this.btnModifierAdresseClient.Location = new System.Drawing.Point(106, 3);
            this.btnModifierAdresseClient.Name = "btnModifierAdresseClient";
            this.btnModifierAdresseClient.Size = new System.Drawing.Size(100, 40);
            this.btnModifierAdresseClient.TabIndex = 3;
            this.btnModifierAdresseClient.Text = "Modifier";
            this.btnModifierAdresseClient.UseVisualStyleBackColor = true;
            this.btnModifierAdresseClient.Click += new System.EventHandler(this.btnModifierAdresseClient_Click);
            // 
            // btnAjouterAdresseClient
            // 
            this.btnAjouterAdresseClient.Location = new System.Drawing.Point(3, 3);
            this.btnAjouterAdresseClient.Name = "btnAjouterAdresseClient";
            this.btnAjouterAdresseClient.Size = new System.Drawing.Size(97, 40);
            this.btnAjouterAdresseClient.TabIndex = 3;
            this.btnAjouterAdresseClient.Text = "Ajouter";
            this.btnAjouterAdresseClient.UseVisualStyleBackColor = true;
            this.btnAjouterAdresseClient.Click += new System.EventHandler(this.btnAjouterAdresseClient_Click);
            // 
            // labelAdressesClient
            // 
            this.labelAdressesClient.AutoSize = true;
            this.labelAdressesClient.Location = new System.Drawing.Point(3, 11);
            this.labelAdressesClient.Name = "labelAdressesClient";
            this.labelAdressesClient.Size = new System.Drawing.Size(158, 17);
            this.labelAdressesClient.TabIndex = 0;
            this.labelAdressesClient.Text = "Les adresses du client :";
            // 
            // panelModifAdresseClient
            // 
            this.panelModifAdresseClient.Controls.Add(this.groupBoxModifAdresseClient);
            this.panelModifAdresseClient.Location = new System.Drawing.Point(3, 369);
            this.panelModifAdresseClient.Name = "panelModifAdresseClient";
            this.panelModifAdresseClient.Size = new System.Drawing.Size(621, 361);
            this.panelModifAdresseClient.TabIndex = 6;
            // 
            // groupBoxModifAdresseClient
            // 
            this.groupBoxModifAdresseClient.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.groupBoxModifAdresseClient.Controls.Add(this.btnAnnulerModifAdresseClient);
            this.groupBoxModifAdresseClient.Controls.Add(this.btnAppliquerModifAdresseClient);
            this.groupBoxModifAdresseClient.Controls.Add(this.textBoxModifVilleClient);
            this.groupBoxModifAdresseClient.Controls.Add(this.labelModifVilleClient);
            this.groupBoxModifAdresseClient.Controls.Add(this.textBoxModifCPClient);
            this.groupBoxModifAdresseClient.Controls.Add(this.labelModifCPClient);
            this.groupBoxModifAdresseClient.Controls.Add(this.textBoxModifAdresse2Client);
            this.groupBoxModifAdresseClient.Controls.Add(this.textBoxModifAdresse1Client);
            this.groupBoxModifAdresseClient.Controls.Add(this.labelModifAdresse1Client);
            this.groupBoxModifAdresseClient.Location = new System.Drawing.Point(3, 3);
            this.groupBoxModifAdresseClient.Name = "groupBoxModifAdresseClient";
            this.groupBoxModifAdresseClient.Size = new System.Drawing.Size(615, 234);
            this.groupBoxModifAdresseClient.TabIndex = 8;
            this.groupBoxModifAdresseClient.TabStop = false;
            this.groupBoxModifAdresseClient.Text = "Adresse";
            this.groupBoxModifAdresseClient.Visible = false;
            // 
            // btnAnnulerModifAdresseClient
            // 
            this.btnAnnulerModifAdresseClient.Location = new System.Drawing.Point(301, 172);
            this.btnAnnulerModifAdresseClient.Name = "btnAnnulerModifAdresseClient";
            this.btnAnnulerModifAdresseClient.Size = new System.Drawing.Size(111, 23);
            this.btnAnnulerModifAdresseClient.TabIndex = 13;
            this.btnAnnulerModifAdresseClient.Text = "Annuler";
            this.btnAnnulerModifAdresseClient.UseVisualStyleBackColor = true;
            this.btnAnnulerModifAdresseClient.Click += new System.EventHandler(this.btnAnnulerModifAdresseClient_Click);
            // 
            // btnAppliquerModifAdresseClient
            // 
            this.btnAppliquerModifAdresseClient.Location = new System.Drawing.Point(212, 172);
            this.btnAppliquerModifAdresseClient.Name = "btnAppliquerModifAdresseClient";
            this.btnAppliquerModifAdresseClient.Size = new System.Drawing.Size(75, 23);
            this.btnAppliquerModifAdresseClient.TabIndex = 13;
            this.btnAppliquerModifAdresseClient.Text = "OK";
            this.btnAppliquerModifAdresseClient.UseVisualStyleBackColor = true;
            this.btnAppliquerModifAdresseClient.Click += new System.EventHandler(this.btnAppliquerModifAdresseClient_Click);
            // 
            // textBoxModifVilleClient
            // 
            this.textBoxModifVilleClient.Location = new System.Drawing.Point(115, 134);
            this.textBoxModifVilleClient.Name = "textBoxModifVilleClient";
            this.textBoxModifVilleClient.Size = new System.Drawing.Size(172, 22);
            this.textBoxModifVilleClient.TabIndex = 13;
            // 
            // labelModifVilleClient
            // 
            this.labelModifVilleClient.AutoSize = true;
            this.labelModifVilleClient.Location = new System.Drawing.Point(7, 134);
            this.labelModifVilleClient.Name = "labelModifVilleClient";
            this.labelModifVilleClient.Size = new System.Drawing.Size(34, 17);
            this.labelModifVilleClient.TabIndex = 13;
            this.labelModifVilleClient.Text = "Ville";
            // 
            // textBoxModifCPClient
            // 
            this.textBoxModifCPClient.Location = new System.Drawing.Point(115, 95);
            this.textBoxModifCPClient.Name = "textBoxModifCPClient";
            this.textBoxModifCPClient.Size = new System.Drawing.Size(172, 22);
            this.textBoxModifCPClient.TabIndex = 13;
            // 
            // labelModifCPClient
            // 
            this.labelModifCPClient.AutoSize = true;
            this.labelModifCPClient.Location = new System.Drawing.Point(7, 98);
            this.labelModifCPClient.Name = "labelModifCPClient";
            this.labelModifCPClient.Size = new System.Drawing.Size(83, 17);
            this.labelModifCPClient.TabIndex = 13;
            this.labelModifCPClient.Text = "Code postal";
            // 
            // textBoxModifAdresse2Client
            // 
            this.textBoxModifAdresse2Client.Location = new System.Drawing.Point(115, 62);
            this.textBoxModifAdresse2Client.Name = "textBoxModifAdresse2Client";
            this.textBoxModifAdresse2Client.Size = new System.Drawing.Size(297, 22);
            this.textBoxModifAdresse2Client.TabIndex = 13;
            // 
            // textBoxModifAdresse1Client
            // 
            this.textBoxModifAdresse1Client.Location = new System.Drawing.Point(115, 34);
            this.textBoxModifAdresse1Client.Name = "textBoxModifAdresse1Client";
            this.textBoxModifAdresse1Client.Size = new System.Drawing.Size(297, 22);
            this.textBoxModifAdresse1Client.TabIndex = 13;
            // 
            // labelModifAdresse1Client
            // 
            this.labelModifAdresse1Client.AutoSize = true;
            this.labelModifAdresse1Client.Location = new System.Drawing.Point(7, 37);
            this.labelModifAdresse1Client.Name = "labelModifAdresse1Client";
            this.labelModifAdresse1Client.Size = new System.Drawing.Size(60, 17);
            this.labelModifAdresse1Client.TabIndex = 13;
            this.labelModifAdresse1Client.Text = "Adresse";
            // 
            // panelClientEtRecherche
            // 
            this.panelClientEtRecherche.Controls.Add(this.groupBoxClient);
            this.panelClientEtRecherche.Location = new System.Drawing.Point(3, 3);
            this.panelClientEtRecherche.Name = "panelClientEtRecherche";
            this.panelClientEtRecherche.Size = new System.Drawing.Size(621, 360);
            this.panelClientEtRecherche.TabIndex = 7;
            // 
            // groupBoxClient
            // 
            this.groupBoxClient.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.groupBoxClient.Controls.Add(this.btnClientAnnuler);
            this.groupBoxClient.Controls.Add(this.btnClientOK);
            this.groupBoxClient.Controls.Add(this.textBoxClientPrenom);
            this.groupBoxClient.Controls.Add(this.textBoxClientNom);
            this.groupBoxClient.Controls.Add(this.labelClientPrenom);
            this.groupBoxClient.Controls.Add(this.labelClientNom);
            this.groupBoxClient.Location = new System.Drawing.Point(2, 3);
            this.groupBoxClient.Name = "groupBoxClient";
            this.groupBoxClient.Size = new System.Drawing.Size(621, 208);
            this.groupBoxClient.TabIndex = 1;
            this.groupBoxClient.TabStop = false;
            this.groupBoxClient.Text = "Client";
            this.groupBoxClient.Visible = false;
            // 
            // btnClientAnnuler
            // 
            this.btnClientAnnuler.Location = new System.Drawing.Point(304, 92);
            this.btnClientAnnuler.Name = "btnClientAnnuler";
            this.btnClientAnnuler.Size = new System.Drawing.Size(111, 23);
            this.btnClientAnnuler.TabIndex = 12;
            this.btnClientAnnuler.Text = "Annuler";
            this.btnClientAnnuler.UseVisualStyleBackColor = true;
            this.btnClientAnnuler.Click += new System.EventHandler(this.btnClientAnnuler_Click);
            // 
            // btnClientOK
            // 
            this.btnClientOK.Location = new System.Drawing.Point(215, 92);
            this.btnClientOK.Name = "btnClientOK";
            this.btnClientOK.Size = new System.Drawing.Size(75, 23);
            this.btnClientOK.TabIndex = 11;
            this.btnClientOK.Text = "OK";
            this.btnClientOK.UseVisualStyleBackColor = true;
            this.btnClientOK.Click += new System.EventHandler(this.btnClientOK_Click);
            // 
            // textBoxClientPrenom
            // 
            this.textBoxClientPrenom.Location = new System.Drawing.Point(118, 54);
            this.textBoxClientPrenom.Name = "textBoxClientPrenom";
            this.textBoxClientPrenom.Size = new System.Drawing.Size(297, 22);
            this.textBoxClientPrenom.TabIndex = 6;
            // 
            // textBoxClientNom
            // 
            this.textBoxClientNom.Location = new System.Drawing.Point(118, 23);
            this.textBoxClientNom.Name = "textBoxClientNom";
            this.textBoxClientNom.Size = new System.Drawing.Size(297, 22);
            this.textBoxClientNom.TabIndex = 5;
            // 
            // labelClientPrenom
            // 
            this.labelClientPrenom.AutoSize = true;
            this.labelClientPrenom.Location = new System.Drawing.Point(7, 57);
            this.labelClientPrenom.Name = "labelClientPrenom";
            this.labelClientPrenom.Size = new System.Drawing.Size(57, 17);
            this.labelClientPrenom.TabIndex = 1;
            this.labelClientPrenom.Text = "Prenom";
            // 
            // labelClientNom
            // 
            this.labelClientNom.AutoSize = true;
            this.labelClientNom.Location = new System.Drawing.Point(7, 23);
            this.labelClientNom.Name = "labelClientNom";
            this.labelClientNom.Size = new System.Drawing.Size(37, 17);
            this.labelClientNom.TabIndex = 0;
            this.labelClientNom.Text = "Nom";
            // 
            // tabCommandes
            // 
            this.tabCommandes.Controls.Add(this.tableLayoutPanelCmd);
            this.tabCommandes.Location = new System.Drawing.Point(4, 25);
            this.tabCommandes.Name = "tabCommandes";
            this.tabCommandes.Padding = new System.Windows.Forms.Padding(3);
            this.tabCommandes.Size = new System.Drawing.Size(1336, 753);
            this.tabCommandes.TabIndex = 1;
            this.tabCommandes.Text = "Commandes";
            this.tabCommandes.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelCmd
            // 
            this.tableLayoutPanelCmd.ColumnCount = 2;
            this.tableLayoutPanelCmd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCmd.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCmd.Controls.Add(this.panelCmd, 1, 0);
            this.tableLayoutPanelCmd.Controls.Add(this.panelContenuCmd, 1, 1);
            this.tableLayoutPanelCmd.Controls.Add(this.groupBoxModifStatutCmd, 0, 0);
            this.tableLayoutPanelCmd.Location = new System.Drawing.Point(0, 3);
            this.tableLayoutPanelCmd.Name = "tableLayoutPanelCmd";
            this.tableLayoutPanelCmd.RowCount = 2;
            this.tableLayoutPanelCmd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCmd.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelCmd.Size = new System.Drawing.Size(1336, 747);
            this.tableLayoutPanelCmd.TabIndex = 0;
            // 
            // panelCmd
            // 
            this.panelCmd.Controls.Add(this.labelCmd);
            this.panelCmd.Controls.Add(this.dataGridViewCmd);
            this.panelCmd.Controls.Add(this.panelBtnCmd);
            this.panelCmd.Location = new System.Drawing.Point(671, 3);
            this.panelCmd.Name = "panelCmd";
            this.panelCmd.Size = new System.Drawing.Size(662, 367);
            this.panelCmd.TabIndex = 0;
            // 
            // labelCmd
            // 
            this.labelCmd.AutoSize = true;
            this.labelCmd.Location = new System.Drawing.Point(3, 15);
            this.labelCmd.Name = "labelCmd";
            this.labelCmd.Size = new System.Drawing.Size(119, 17);
            this.labelCmd.TabIndex = 2;
            this.labelCmd.Text = "Les commandes :";
            // 
            // dataGridViewCmd
            // 
            this.dataGridViewCmd.AllowUserToAddRows = false;
            this.dataGridViewCmd.AllowUserToDeleteRows = false;
            this.dataGridViewCmd.AllowUserToResizeColumns = false;
            this.dataGridViewCmd.AllowUserToResizeRows = false;
            this.dataGridViewCmd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCmd.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NumeroCmd,
            this.idClient,
            this.dateCmd,
            this.fraisPort,
            this.totalCmd,
            this.statutCmd});
            this.dataGridViewCmd.Location = new System.Drawing.Point(3, 55);
            this.dataGridViewCmd.MultiSelect = false;
            this.dataGridViewCmd.Name = "dataGridViewCmd";
            this.dataGridViewCmd.ReadOnly = true;
            this.dataGridViewCmd.RowTemplate.Height = 24;
            this.dataGridViewCmd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCmd.Size = new System.Drawing.Size(659, 309);
            this.dataGridViewCmd.TabIndex = 1;
            this.dataGridViewCmd.SelectionChanged += new System.EventHandler(this.dataGridViewCmd_SelectionChanged);
            // 
            // NumeroCmd
            // 
            this.NumeroCmd.DataPropertyName = "IdCommande";
            this.NumeroCmd.HeaderText = "Id commande";
            this.NumeroCmd.Name = "NumeroCmd";
            this.NumeroCmd.ReadOnly = true;
            // 
            // idClient
            // 
            this.idClient.DataPropertyName = "CmdIdClient";
            this.idClient.HeaderText = "Id client";
            this.idClient.Name = "idClient";
            this.idClient.ReadOnly = true;
            // 
            // dateCmd
            // 
            this.dateCmd.DataPropertyName = "DateCommande";
            this.dateCmd.HeaderText = "Date";
            this.dateCmd.Name = "dateCmd";
            this.dateCmd.ReadOnly = true;
            // 
            // fraisPort
            // 
            this.fraisPort.DataPropertyName = "FraisPort";
            this.fraisPort.HeaderText = "Frais de port";
            this.fraisPort.Name = "fraisPort";
            this.fraisPort.ReadOnly = true;
            // 
            // totalCmd
            // 
            this.totalCmd.DataPropertyName = "PrixTotalCommande";
            this.totalCmd.HeaderText = "Prix total";
            this.totalCmd.Name = "totalCmd";
            this.totalCmd.ReadOnly = true;
            // 
            // statutCmd
            // 
            this.statutCmd.DataPropertyName = "StatutCommande";
            this.statutCmd.HeaderText = "Statut";
            this.statutCmd.Name = "statutCmd";
            this.statutCmd.ReadOnly = true;
            // 
            // panelBtnCmd
            // 
            this.panelBtnCmd.Controls.Add(this.btnModifStatut);
            this.panelBtnCmd.Location = new System.Drawing.Point(409, 3);
            this.panelBtnCmd.Name = "panelBtnCmd";
            this.panelBtnCmd.Size = new System.Drawing.Size(121, 46);
            this.panelBtnCmd.TabIndex = 0;
            // 
            // btnModifStatut
            // 
            this.btnModifStatut.Location = new System.Drawing.Point(3, 5);
            this.btnModifStatut.Name = "btnModifStatut";
            this.btnModifStatut.Size = new System.Drawing.Size(109, 38);
            this.btnModifStatut.TabIndex = 8;
            this.btnModifStatut.Text = "Modifier";
            this.btnModifStatut.UseVisualStyleBackColor = true;
            this.btnModifStatut.Click += new System.EventHandler(this.btnModifStatut_Click);
            // 
            // panelContenuCmd
            // 
            this.panelContenuCmd.Controls.Add(this.dataGridViewContenuCmd);
            this.panelContenuCmd.Controls.Add(this.labelContenuCmd);
            this.panelContenuCmd.Location = new System.Drawing.Point(671, 376);
            this.panelContenuCmd.Name = "panelContenuCmd";
            this.panelContenuCmd.Size = new System.Drawing.Size(662, 368);
            this.panelContenuCmd.TabIndex = 2;
            // 
            // dataGridViewContenuCmd
            // 
            this.dataGridViewContenuCmd.AllowUserToAddRows = false;
            this.dataGridViewContenuCmd.AllowUserToDeleteRows = false;
            this.dataGridViewContenuCmd.AllowUserToResizeColumns = false;
            this.dataGridViewContenuCmd.AllowUserToResizeRows = false;
            this.dataGridViewContenuCmd.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewContenuCmd.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idContenuCmd,
            this.idProduit,
            this.qteProduit,
            this.prixUnitaire});
            this.dataGridViewContenuCmd.Location = new System.Drawing.Point(3, 62);
            this.dataGridViewContenuCmd.MultiSelect = false;
            this.dataGridViewContenuCmd.Name = "dataGridViewContenuCmd";
            this.dataGridViewContenuCmd.ReadOnly = true;
            this.dataGridViewContenuCmd.RowTemplate.Height = 24;
            this.dataGridViewContenuCmd.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewContenuCmd.Size = new System.Drawing.Size(653, 303);
            this.dataGridViewContenuCmd.TabIndex = 4;
            // 
            // labelContenuCmd
            // 
            this.labelContenuCmd.AutoSize = true;
            this.labelContenuCmd.Location = new System.Drawing.Point(3, 25);
            this.labelContenuCmd.Name = "labelContenuCmd";
            this.labelContenuCmd.Size = new System.Drawing.Size(177, 17);
            this.labelContenuCmd.TabIndex = 3;
            this.labelContenuCmd.Text = "Contenu de le commande :";
            // 
            // groupBoxModifStatutCmd
            // 
            this.groupBoxModifStatutCmd.Controls.Add(this.comboBoxStatutCmd);
            this.groupBoxModifStatutCmd.Controls.Add(this.btnModifierStatutCmd);
            this.groupBoxModifStatutCmd.Controls.Add(this.labelStatutCmd);
            this.groupBoxModifStatutCmd.Location = new System.Drawing.Point(3, 3);
            this.groupBoxModifStatutCmd.Name = "groupBoxModifStatutCmd";
            this.groupBoxModifStatutCmd.Size = new System.Drawing.Size(662, 201);
            this.groupBoxModifStatutCmd.TabIndex = 3;
            this.groupBoxModifStatutCmd.TabStop = false;
            this.groupBoxModifStatutCmd.Text = "Modification statut";
            this.groupBoxModifStatutCmd.Visible = false;
            // 
            // comboBoxStatutCmd
            // 
            this.comboBoxStatutCmd.FormattingEnabled = true;
            this.comboBoxStatutCmd.Location = new System.Drawing.Point(202, 40);
            this.comboBoxStatutCmd.Name = "comboBoxStatutCmd";
            this.comboBoxStatutCmd.Size = new System.Drawing.Size(121, 24);
            this.comboBoxStatutCmd.TabIndex = 7;
            // 
            // btnModifierStatutCmd
            // 
            this.btnModifierStatutCmd.Location = new System.Drawing.Point(256, 102);
            this.btnModifierStatutCmd.Name = "btnModifierStatutCmd";
            this.btnModifierStatutCmd.Size = new System.Drawing.Size(109, 30);
            this.btnModifierStatutCmd.TabIndex = 6;
            this.btnModifierStatutCmd.Text = "Modifier";
            this.btnModifierStatutCmd.UseVisualStyleBackColor = true;
            this.btnModifierStatutCmd.Click += new System.EventHandler(this.btnModifierStatutCmd_Click);
            // 
            // labelStatutCmd
            // 
            this.labelStatutCmd.AutoSize = true;
            this.labelStatutCmd.Location = new System.Drawing.Point(15, 40);
            this.labelStatutCmd.Name = "labelStatutCmd";
            this.labelStatutCmd.Size = new System.Drawing.Size(161, 17);
            this.labelStatutCmd.TabIndex = 0;
            this.labelStatutCmd.Text = "Statut de la commande :";
            // 
            // tabProduits
            // 
            this.tabProduits.Controls.Add(this.tableLayoutPanelPdt);
            this.tabProduits.Location = new System.Drawing.Point(4, 25);
            this.tabProduits.Name = "tabProduits";
            this.tabProduits.Size = new System.Drawing.Size(1336, 753);
            this.tabProduits.TabIndex = 2;
            this.tabProduits.Text = "Produits";
            this.tabProduits.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanelPdt
            // 
            this.tableLayoutPanelPdt.ColumnCount = 2;
            this.tableLayoutPanelPdt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelPdt.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelPdt.Controls.Add(this.groupBoxPdt, 0, 0);
            this.tableLayoutPanelPdt.Controls.Add(this.panelPdt, 1, 0);
            this.tableLayoutPanelPdt.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelPdt.Name = "tableLayoutPanelPdt";
            this.tableLayoutPanelPdt.RowCount = 2;
            this.tableLayoutPanelPdt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelPdt.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelPdt.Size = new System.Drawing.Size(1333, 747);
            this.tableLayoutPanelPdt.TabIndex = 0;
            // 
            // groupBoxPdt
            // 
            this.groupBoxPdt.Controls.Add(this.comboBoxCategoriePdt);
            this.groupBoxPdt.Controls.Add(this.labelCategoriePdt);
            this.groupBoxPdt.Controls.Add(this.btnAnnulerPdt);
            this.groupBoxPdt.Controls.Add(this.richTextBoxDescriptionPdt);
            this.groupBoxPdt.Controls.Add(this.numericUpDownQtePdt);
            this.groupBoxPdt.Controls.Add(this.btnOkPdt);
            this.groupBoxPdt.Controls.Add(this.textBoxReferencePdt);
            this.groupBoxPdt.Controls.Add(this.textBoxPrixPdt);
            this.groupBoxPdt.Controls.Add(this.textBoxLibellePdt);
            this.groupBoxPdt.Controls.Add(this.labelDescriptionPdt);
            this.groupBoxPdt.Controls.Add(this.labelQtePdt);
            this.groupBoxPdt.Controls.Add(this.labelReferencePdt);
            this.groupBoxPdt.Controls.Add(this.labelPrixUnitairePdt);
            this.groupBoxPdt.Controls.Add(this.labelLibellePdt);
            this.groupBoxPdt.Location = new System.Drawing.Point(3, 3);
            this.groupBoxPdt.Name = "groupBoxPdt";
            this.groupBoxPdt.Size = new System.Drawing.Size(660, 361);
            this.groupBoxPdt.TabIndex = 3;
            this.groupBoxPdt.TabStop = false;
            this.groupBoxPdt.Text = "Produit";
            this.groupBoxPdt.Visible = false;
            // 
            // comboBoxCategoriePdt
            // 
            this.comboBoxCategoriePdt.FormattingEnabled = true;
            this.comboBoxCategoriePdt.Location = new System.Drawing.Point(151, 262);
            this.comboBoxCategoriePdt.Name = "comboBoxCategoriePdt";
            this.comboBoxCategoriePdt.Size = new System.Drawing.Size(120, 24);
            this.comboBoxCategoriePdt.TabIndex = 13;
            // 
            // labelCategoriePdt
            // 
            this.labelCategoriePdt.AutoSize = true;
            this.labelCategoriePdt.Location = new System.Drawing.Point(9, 269);
            this.labelCategoriePdt.Name = "labelCategoriePdt";
            this.labelCategoriePdt.Size = new System.Drawing.Size(69, 17);
            this.labelCategoriePdt.TabIndex = 12;
            this.labelCategoriePdt.Text = "Catégorie";
            // 
            // btnAnnulerPdt
            // 
            this.btnAnnulerPdt.Location = new System.Drawing.Point(414, 327);
            this.btnAnnulerPdt.Name = "btnAnnulerPdt";
            this.btnAnnulerPdt.Size = new System.Drawing.Size(97, 34);
            this.btnAnnulerPdt.TabIndex = 11;
            this.btnAnnulerPdt.Text = "Annuler";
            this.btnAnnulerPdt.UseVisualStyleBackColor = true;
            this.btnAnnulerPdt.Click += new System.EventHandler(this.btnAnnulerPdt_Click);
            // 
            // richTextBoxDescriptionPdt
            // 
            this.richTextBoxDescriptionPdt.Location = new System.Drawing.Point(151, 190);
            this.richTextBoxDescriptionPdt.Name = "richTextBoxDescriptionPdt";
            this.richTextBoxDescriptionPdt.Size = new System.Drawing.Size(431, 54);
            this.richTextBoxDescriptionPdt.TabIndex = 10;
            this.richTextBoxDescriptionPdt.Text = "";
            // 
            // numericUpDownQtePdt
            // 
            this.numericUpDownQtePdt.Location = new System.Drawing.Point(151, 145);
            this.numericUpDownQtePdt.Name = "numericUpDownQtePdt";
            this.numericUpDownQtePdt.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownQtePdt.TabIndex = 9;
            this.numericUpDownQtePdt.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnOkPdt
            // 
            this.btnOkPdt.Location = new System.Drawing.Point(296, 327);
            this.btnOkPdt.Name = "btnOkPdt";
            this.btnOkPdt.Size = new System.Drawing.Size(97, 34);
            this.btnOkPdt.TabIndex = 1;
            this.btnOkPdt.Text = "OK";
            this.btnOkPdt.UseVisualStyleBackColor = true;
            this.btnOkPdt.Click += new System.EventHandler(this.btnOkPdt_Click);
            // 
            // textBoxReferencePdt
            // 
            this.textBoxReferencePdt.Location = new System.Drawing.Point(151, 103);
            this.textBoxReferencePdt.Name = "textBoxReferencePdt";
            this.textBoxReferencePdt.Size = new System.Drawing.Size(261, 22);
            this.textBoxReferencePdt.TabIndex = 7;
            // 
            // textBoxPrixPdt
            // 
            this.textBoxPrixPdt.Location = new System.Drawing.Point(151, 68);
            this.textBoxPrixPdt.Name = "textBoxPrixPdt";
            this.textBoxPrixPdt.Size = new System.Drawing.Size(110, 22);
            this.textBoxPrixPdt.TabIndex = 6;
            // 
            // textBoxLibellePdt
            // 
            this.textBoxLibellePdt.Location = new System.Drawing.Point(151, 31);
            this.textBoxLibellePdt.Name = "textBoxLibellePdt";
            this.textBoxLibellePdt.Size = new System.Drawing.Size(431, 22);
            this.textBoxLibellePdt.TabIndex = 5;
            // 
            // labelDescriptionPdt
            // 
            this.labelDescriptionPdt.AutoSize = true;
            this.labelDescriptionPdt.Location = new System.Drawing.Point(6, 190);
            this.labelDescriptionPdt.Name = "labelDescriptionPdt";
            this.labelDescriptionPdt.Size = new System.Drawing.Size(79, 17);
            this.labelDescriptionPdt.TabIndex = 4;
            this.labelDescriptionPdt.Text = "Description";
            // 
            // labelQtePdt
            // 
            this.labelQtePdt.AutoSize = true;
            this.labelQtePdt.Location = new System.Drawing.Point(6, 145);
            this.labelQtePdt.Name = "labelQtePdt";
            this.labelQtePdt.Size = new System.Drawing.Size(62, 17);
            this.labelQtePdt.TabIndex = 3;
            this.labelQtePdt.Text = "Quantité";
            // 
            // labelReferencePdt
            // 
            this.labelReferencePdt.AutoSize = true;
            this.labelReferencePdt.Location = new System.Drawing.Point(6, 103);
            this.labelReferencePdt.Name = "labelReferencePdt";
            this.labelReferencePdt.Size = new System.Drawing.Size(74, 17);
            this.labelReferencePdt.TabIndex = 2;
            this.labelReferencePdt.Text = "Référence";
            // 
            // labelPrixUnitairePdt
            // 
            this.labelPrixUnitairePdt.AutoSize = true;
            this.labelPrixUnitairePdt.Location = new System.Drawing.Point(6, 68);
            this.labelPrixUnitairePdt.Name = "labelPrixUnitairePdt";
            this.labelPrixUnitairePdt.Size = new System.Drawing.Size(82, 17);
            this.labelPrixUnitairePdt.TabIndex = 1;
            this.labelPrixUnitairePdt.Text = "Prix unitaire";
            // 
            // labelLibellePdt
            // 
            this.labelLibellePdt.AutoSize = true;
            this.labelLibellePdt.Location = new System.Drawing.Point(6, 31);
            this.labelLibellePdt.Name = "labelLibellePdt";
            this.labelLibellePdt.Size = new System.Drawing.Size(49, 17);
            this.labelLibellePdt.TabIndex = 0;
            this.labelLibellePdt.Text = "Libellé";
            // 
            // panelPdt
            // 
            this.panelPdt.Controls.Add(this.labelLesProduits);
            this.panelPdt.Controls.Add(this.dataGridViewPdt);
            this.panelPdt.Controls.Add(this.panelBtnPdt);
            this.panelPdt.Location = new System.Drawing.Point(669, 3);
            this.panelPdt.Name = "panelPdt";
            this.panelPdt.Size = new System.Drawing.Size(661, 367);
            this.panelPdt.TabIndex = 2;
            // 
            // labelLesProduits
            // 
            this.labelLesProduits.AutoSize = true;
            this.labelLesProduits.Location = new System.Drawing.Point(2, 15);
            this.labelLesProduits.Name = "labelLesProduits";
            this.labelLesProduits.Size = new System.Drawing.Size(94, 17);
            this.labelLesProduits.TabIndex = 2;
            this.labelLesProduits.Text = "Les produits :";
            // 
            // dataGridViewPdt
            // 
            this.dataGridViewPdt.AllowUserToAddRows = false;
            this.dataGridViewPdt.AllowUserToDeleteRows = false;
            this.dataGridViewPdt.AllowUserToResizeColumns = false;
            this.dataGridViewPdt.AllowUserToResizeRows = false;
            this.dataGridViewPdt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPdt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idPdt,
            this.libellePdt,
            this.prixUnitairePdt,
            this.qtePdt,
            this.referencePdt,
            this.categoriePdt});
            this.dataGridViewPdt.Location = new System.Drawing.Point(0, 54);
            this.dataGridViewPdt.MultiSelect = false;
            this.dataGridViewPdt.Name = "dataGridViewPdt";
            this.dataGridViewPdt.ReadOnly = true;
            this.dataGridViewPdt.RowTemplate.Height = 24;
            this.dataGridViewPdt.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPdt.Size = new System.Drawing.Size(658, 313);
            this.dataGridViewPdt.TabIndex = 1;
            // 
            // idPdt
            // 
            this.idPdt.DataPropertyName = "IdProduit";
            this.idPdt.HeaderText = "Id produit";
            this.idPdt.Name = "idPdt";
            this.idPdt.ReadOnly = true;
            // 
            // libellePdt
            // 
            this.libellePdt.DataPropertyName = "LibelleProduit";
            this.libellePdt.HeaderText = "Libellé ";
            this.libellePdt.Name = "libellePdt";
            this.libellePdt.ReadOnly = true;
            // 
            // prixUnitairePdt
            // 
            this.prixUnitairePdt.DataPropertyName = "PrixUnitaireProduit";
            this.prixUnitairePdt.HeaderText = "Prix unitaire";
            this.prixUnitairePdt.Name = "prixUnitairePdt";
            this.prixUnitairePdt.ReadOnly = true;
            // 
            // qtePdt
            // 
            this.qtePdt.DataPropertyName = "QuantiteProduit";
            this.qtePdt.HeaderText = "Quantité";
            this.qtePdt.Name = "qtePdt";
            this.qtePdt.ReadOnly = true;
            // 
            // referencePdt
            // 
            this.referencePdt.DataPropertyName = "ReferenceProduit";
            this.referencePdt.HeaderText = "Référence";
            this.referencePdt.Name = "referencePdt";
            this.referencePdt.ReadOnly = true;
            // 
            // categoriePdt
            // 
            this.categoriePdt.DataPropertyName = "ProduitLblCat";
            this.categoriePdt.HeaderText = "Catégorie";
            this.categoriePdt.Name = "categoriePdt";
            this.categoriePdt.ReadOnly = true;
            // 
            // panelBtnPdt
            // 
            this.panelBtnPdt.Controls.Add(this.btnSupprimerPdt);
            this.panelBtnPdt.Controls.Add(this.btnModifierPdt);
            this.panelBtnPdt.Controls.Add(this.btnAjouterPdt);
            this.panelBtnPdt.Location = new System.Drawing.Point(158, 3);
            this.panelBtnPdt.Name = "panelBtnPdt";
            this.panelBtnPdt.Size = new System.Drawing.Size(308, 45);
            this.panelBtnPdt.TabIndex = 0;
            // 
            // btnSupprimerPdt
            // 
            this.btnSupprimerPdt.Location = new System.Drawing.Point(206, 3);
            this.btnSupprimerPdt.Name = "btnSupprimerPdt";
            this.btnSupprimerPdt.Size = new System.Drawing.Size(97, 34);
            this.btnSupprimerPdt.TabIndex = 16;
            this.btnSupprimerPdt.Text = "Supprimer";
            this.btnSupprimerPdt.UseVisualStyleBackColor = true;
            this.btnSupprimerPdt.Click += new System.EventHandler(this.btnSupprimerPdt_Click);
            // 
            // btnModifierPdt
            // 
            this.btnModifierPdt.Location = new System.Drawing.Point(103, 3);
            this.btnModifierPdt.Name = "btnModifierPdt";
            this.btnModifierPdt.Size = new System.Drawing.Size(97, 34);
            this.btnModifierPdt.TabIndex = 15;
            this.btnModifierPdt.Text = "Modifier";
            this.btnModifierPdt.UseVisualStyleBackColor = true;
            this.btnModifierPdt.Click += new System.EventHandler(this.btnModifierPdt_Click);
            // 
            // btnAjouterPdt
            // 
            this.btnAjouterPdt.Location = new System.Drawing.Point(0, 3);
            this.btnAjouterPdt.Name = "btnAjouterPdt";
            this.btnAjouterPdt.Size = new System.Drawing.Size(97, 34);
            this.btnAjouterPdt.TabIndex = 14;
            this.btnAjouterPdt.Text = "Ajouter";
            this.btnAjouterPdt.UseVisualStyleBackColor = true;
            this.btnAjouterPdt.Click += new System.EventHandler(this.btnAjouterPdt_Click);
            // 
            // idContenuCmd
            // 
            this.idContenuCmd.DataPropertyName = "IdContenuCommande";
            this.idContenuCmd.HeaderText = "Id contenu commmande";
            this.idContenuCmd.Name = "idContenuCmd";
            this.idContenuCmd.ReadOnly = true;
            // 
            // idProduit
            // 
            this.idProduit.DataPropertyName = "ContenuCmdIdProduit";
            this.idProduit.HeaderText = "Id produit";
            this.idProduit.Name = "idProduit";
            this.idProduit.ReadOnly = true;
            // 
            // qteProduit
            // 
            this.qteProduit.DataPropertyName = "QuantiteContenuCommande";
            this.qteProduit.HeaderText = "Quantité";
            this.qteProduit.Name = "qteProduit";
            this.qteProduit.ReadOnly = true;
            // 
            // prixUnitaire
            // 
            this.prixUnitaire.DataPropertyName = "PrixUnitaireContenuCommande";
            this.prixUnitaire.HeaderText = "Prix unitaire";
            this.prixUnitaire.Name = "prixUnitaire";
            this.prixUnitaire.ReadOnly = true;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1356, 794);
            this.Controls.Add(this.tabControl);
            this.Name = "FrmMain";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmMain_FormClosed);
            this.tabControl.ResumeLayout(false);
            this.tabClients.ResumeLayout(false);
            this.tableLayoutPanelClient.ResumeLayout(false);
            this.panelClient.ResumeLayout(false);
            this.panelClient.PerformLayout();
            this.panelBtnClients.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).EndInit();
            this.panelAdressesClient.ResumeLayout(false);
            this.panelAdressesClient.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAdressesClient)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panelModifAdresseClient.ResumeLayout(false);
            this.groupBoxModifAdresseClient.ResumeLayout(false);
            this.groupBoxModifAdresseClient.PerformLayout();
            this.panelClientEtRecherche.ResumeLayout(false);
            this.groupBoxClient.ResumeLayout(false);
            this.groupBoxClient.PerformLayout();
            this.tabCommandes.ResumeLayout(false);
            this.tableLayoutPanelCmd.ResumeLayout(false);
            this.panelCmd.ResumeLayout(false);
            this.panelCmd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCmd)).EndInit();
            this.panelBtnCmd.ResumeLayout(false);
            this.panelContenuCmd.ResumeLayout(false);
            this.panelContenuCmd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewContenuCmd)).EndInit();
            this.groupBoxModifStatutCmd.ResumeLayout(false);
            this.groupBoxModifStatutCmd.PerformLayout();
            this.tabProduits.ResumeLayout(false);
            this.tableLayoutPanelPdt.ResumeLayout(false);
            this.groupBoxPdt.ResumeLayout(false);
            this.groupBoxPdt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownQtePdt)).EndInit();
            this.panelPdt.ResumeLayout(false);
            this.panelPdt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPdt)).EndInit();
            this.panelBtnPdt.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabClients;
        private System.Windows.Forms.TabPage tabCommandes;
        private System.Windows.Forms.TabPage tabProduits;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelClient;
        private System.Windows.Forms.DataGridView dataGridViewClient;
        private System.Windows.Forms.Panel panelClient;
        private System.Windows.Forms.Panel panelBtnClients;
        private System.Windows.Forms.Button btnSupprimerClient;
        private System.Windows.Forms.Button btnModifierClient;
        private System.Windows.Forms.Button btnAjouterClient;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelCmd;
        private System.Windows.Forms.Panel panelCmd;
        private System.Windows.Forms.DataGridView dataGridViewCmd;
        private System.Windows.Forms.Panel panelBtnCmd;
        private System.Windows.Forms.Label labelCmd;
        private System.Windows.Forms.Panel panelContenuCmd;
        private System.Windows.Forms.DataGridView dataGridViewContenuCmd;
        private System.Windows.Forms.Label labelContenuCmd;
        private System.Windows.Forms.Panel panelAdressesClient;
        private System.Windows.Forms.Label labelAdressesClient;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPdt;
        private System.Windows.Forms.Panel panelPdt;
        private System.Windows.Forms.DataGridView dataGridViewPdt;
        private System.Windows.Forms.Panel panelBtnPdt;
        private System.Windows.Forms.Button btnSupprimerPdt;
        private System.Windows.Forms.Button btnModifierPdt;
        private System.Windows.Forms.Button btnAjouterPdt;
        private System.Windows.Forms.DataGridView dataGridViewAdressesClient;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSupprimerAdresseClient;
        private System.Windows.Forms.Button btnModifierAdresseClient;
        private System.Windows.Forms.Button btnAjouterAdresseClient;
        private System.Windows.Forms.GroupBox groupBoxModifStatutCmd;
        private System.Windows.Forms.Button btnModifierStatutCmd;
        private System.Windows.Forms.Label labelStatutCmd;
        private System.Windows.Forms.Panel panelModifAdresseClient;
        private System.Windows.Forms.GroupBox groupBoxModifAdresseClient;
        private System.Windows.Forms.Button btnAnnulerModifAdresseClient;
        private System.Windows.Forms.Button btnAppliquerModifAdresseClient;
        private System.Windows.Forms.TextBox textBoxModifVilleClient;
        private System.Windows.Forms.Label labelModifVilleClient;
        private System.Windows.Forms.TextBox textBoxModifCPClient;
        private System.Windows.Forms.Label labelModifCPClient;
        private System.Windows.Forms.TextBox textBoxModifAdresse2Client;
        private System.Windows.Forms.TextBox textBoxModifAdresse1Client;
        private System.Windows.Forms.Label labelModifAdresse1Client;
        private System.Windows.Forms.Panel panelClientEtRecherche;
        private System.Windows.Forms.GroupBox groupBoxClient;
        private System.Windows.Forms.Button btnClientAnnuler;
        private System.Windows.Forms.Button btnClientOK;
        private System.Windows.Forms.TextBox textBoxClientPrenom;
        private System.Windows.Forms.TextBox textBoxClientNom;
        private System.Windows.Forms.Label labelClientPrenom;
        private System.Windows.Forms.Label labelClientNom;
        private System.Windows.Forms.Label labelLesClients;
        private System.Windows.Forms.Label labelLesProduits;
        private System.Windows.Forms.GroupBox groupBoxPdt;
        private System.Windows.Forms.Label labelCategoriePdt;
        private System.Windows.Forms.Button btnAnnulerPdt;
        private System.Windows.Forms.RichTextBox richTextBoxDescriptionPdt;
        private System.Windows.Forms.NumericUpDown numericUpDownQtePdt;
        private System.Windows.Forms.Button btnOkPdt;
        private System.Windows.Forms.TextBox textBoxReferencePdt;
        private System.Windows.Forms.TextBox textBoxPrixPdt;
        private System.Windows.Forms.TextBox textBoxLibellePdt;
        private System.Windows.Forms.Label labelDescriptionPdt;
        private System.Windows.Forms.Label labelQtePdt;
        private System.Windows.Forms.Label labelReferencePdt;
        private System.Windows.Forms.Label labelPrixUnitairePdt;
        private System.Windows.Forms.Label labelLibellePdt;
        private System.Windows.Forms.ComboBox comboBoxCategoriePdt;
        private System.Windows.Forms.ComboBox comboBoxStatutCmd;
        private System.Windows.Forms.Button btnModifStatut;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumeroClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrenomClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn actif;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAdresse;
        private System.Windows.Forms.DataGridViewTextBoxColumn voie;
        private System.Windows.Forms.DataGridViewTextBoxColumn complement;
        private System.Windows.Forms.DataGridViewTextBoxColumn codePostal;
        private System.Windows.Forms.DataGridViewTextBoxColumn ville;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumeroCmd;
        private System.Windows.Forms.DataGridViewTextBoxColumn idClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateCmd;
        private System.Windows.Forms.DataGridViewTextBoxColumn fraisPort;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalCmd;
        private System.Windows.Forms.DataGridViewTextBoxColumn statutCmd;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn libellePdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn prixUnitairePdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtePdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn referencePdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoriePdt;
        private System.Windows.Forms.DataGridViewTextBoxColumn idContenuCmd;
        private System.Windows.Forms.DataGridViewTextBoxColumn idProduit;
        private System.Windows.Forms.DataGridViewTextBoxColumn qteProduit;
        private System.Windows.Forms.DataGridViewTextBoxColumn prixUnitaire;
    }
}

