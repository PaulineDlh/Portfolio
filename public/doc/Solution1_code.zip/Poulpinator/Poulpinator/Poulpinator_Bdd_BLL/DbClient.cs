﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poulpinator_Classes_BLL;
using MySql.Data.MySqlClient;

namespace Poulpinator_Bdd_BLL
{
    public static class DbClient
    {
        public static List<Client> GetClients()
        {
            List<Client> Clients = new List<Client>();

            String sql = "SELECT c.id_client, c.prenom, c.nom, c.actif FROM client as c ";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            MySqlDataReader res = req.ExecuteReader();

            if (res.HasRows)
            {
                while (res.Read())
                {
                    Clients.Add(
                        new Client(
                            res.GetInt32("id_client"),
                            res.IsDBNull(1) ? null : res.GetString("prenom"),
                            res.IsDBNull(2) ? null : res.GetString("nom"),
                            res.GetInt32("actif")
                            )
                        );
                }
            }

            res.Close();

            return Clients;
        }

        public static int CreerClient(Client client)
        {
            String sql = "INSERT INTO client(nom, prenom)" + "VALUE(@clientNom, @clientPrenom)";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@clientNom", client.NomClient));
            req.Parameters.Add(new MySqlParameter("@clientPrenom", client.PrenomClient));

            req.ExecuteNonQuery();

            return int.Parse(req.LastInsertedId.ToString());
        }

        public static void UpdateClient(Client client)
        {
            String sql = "UPDATE client SET nom = @clientNom, prenom = @clientPrenom WHERE id_client = @clientId ";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@clientNom", client.NomClient));
            req.Parameters.Add(new MySqlParameter("@clientPrenom", client.PrenomClient));
            req.Parameters.Add(new MySqlParameter("@clientId", client.IdClient));

            req.ExecuteNonQuery();
        }

        public static void DesactiverClient(Client client)
        {
            String sql = "UPDATE client SET actif = 0 WHERE id_client = @clientId ";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@clientId", client.IdClient));

            req.ExecuteNonQuery();
        }

        public static List<Adresse> GetAdresses(Client client)
        {
            List<Adresse> Adresses = new List<Adresse>();

            String sql = "SELECT a.id_adresse, a.voie, a.complement, a.code_postal, a.ville FROM adresse as a WHERE a.id_client = @clientId ";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@clientId", client.IdClient));

            MySqlDataReader res = req.ExecuteReader();

            if (res.HasRows)
            {
                while (res.Read())
                {
                    Adresses.Add(
                        new Adresse(
                            res.GetInt32("id_adresse"),
                            res.GetString("voie"),
                            res.IsDBNull(2) ? null : res.GetString("complement"),
                            res.GetString("code_postal"),
                            res.GetString("ville"),
                            client
                            )
                        );
                }
            }

            res.Close();

            if (client.GetLesAdresses() != null) client.GetLesAdresses().Clear();
            client.SetLesAdresse(Adresses);

            return Adresses;
        }

        public static int CreerAdresse(Adresse adresse)
        {
            String sql = "INSERT INTO adresse(voie, complement, code_postal, ville, id_client) " + "VALUE(@adresseVoie, adresseComplement, adresseCodePostal, @adresseVille, @adresseClientId)";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@adresseVoie", adresse.Voie));
            req.Parameters.Add(new MySqlParameter("@adresseComplement", adresse.Complement));
            req.Parameters.Add(new MySqlParameter("@adresseCodePostal", adresse.CodePostal));
            req.Parameters.Add(new MySqlParameter("@adresseVille", adresse.Ville));
            req.Parameters.Add(new MySqlParameter("@adresseClientId", adresse.GetClient().IdClient));

            req.ExecuteNonQuery();

            return int.Parse(req.LastInsertedId.ToString());
        }

        public static void UpdateAdresse(Adresse adresse)
        {
            String sql = "UPDATE adresse SET voie = @adresseVoie, complement = @adresseComplement, code_postal = @adresseCodePostal, ville = @adresseVille " + "WHERE id_adresse = @adresseId";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@adresseVoie", adresse.Voie));
            req.Parameters.Add(new MySqlParameter("@adresseComplement", adresse.Complement));
            req.Parameters.Add(new MySqlParameter("@adresseCodePostal", adresse.CodePostal));
            req.Parameters.Add(new MySqlParameter("@adresseVille", adresse.Ville));
            req.Parameters.Add(new MySqlParameter("@adresseId", adresse.IdAdresse));

            req.ExecuteNonQuery();
        }

        public static void SupprimerAdresse(Adresse adresse)
        {
            String sql = "DELETE FROM adresse WHERE id_adresse = @adresseId";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.ExecuteNonQuery();
        }
    }
}
