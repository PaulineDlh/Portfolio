﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poulpinator_Classes_BLL;
using MySql.Data.MySqlClient;

namespace Poulpinator_Bdd_BLL
{
    public static class DbProduit
    {
        public static List<Produit> GetProduits()
        {
            List<Produit> Produits = new List<Produit>();

            String sql = "SELECT p.id_produit, p.libelle_produit, p.prix_unitaire_HT, p.quantite_produit, p.reference, " +
                "c.libelle_categorie, c.id_categorie " +
                "FROM produit as p, categorie as c " +
                "WHERE p.id_categorie = c.id_categorie ";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            MySqlDataReader res = req.ExecuteReader();

            if (res.HasRows)
            {
                while (res.Read())
                {
                    Produits.Add(
                        new Produit(
                            res.GetInt32("id_produit"),
                            res.GetString("libelle_produit"),
                            res.GetInt32("prix_unitaire_HT"),
                            res.GetInt32("quantite_produit"),
                            res.GetString("reference"),
                            new Categorie(res.GetInt32("id_categorie"), res.GetString("libelle_categorie"))
                            )
                        );
                }
            }

            res.Close();

            return Produits;
        }

        public static List<Categorie> GetCategories()
        {
            List<Categorie> Categories = new List<Categorie>();

            String sql = "SELECT id_categorie, libelle_categorie FROM categorie";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            MySqlDataReader res = req.ExecuteReader();

            if (res.HasRows)
            {
                while (res.Read())
                {
                    Categories.Add(
                        new Categorie(
                            res.GetInt32("id_categorie"),
                            res.GetString("libelle_categorie")
                            )
                        );
                }
            }

            res.Close();

            return Categories;
        }

        public static int CreerProduit(Produit produit)
        {
            String sql = "INSERT INTO produit(libelle_produit, prix_unitaire_HT, reference, quantite_produit, description_produit, id_categorie)" +
                "VALUE(@produitLibelle, @produitPrix, @produitReference, @produitQuantite, @produitDescription, @produitIdCategorie)";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@produitLibelle", produit.LibelleProduit));
            req.Parameters.Add(new MySqlParameter("@produitPrix", produit.PrixUnitaireProduit));
            req.Parameters.Add(new MySqlParameter("@produitReference", produit.ReferenceProduit));
            req.Parameters.Add(new MySqlParameter("@produitQuantite", produit.QuantiteProduit));
            req.Parameters.Add(new MySqlParameter("@produitDescription", produit.DescriptionProduit));

            if(produit.GetLaCategorie() == null || produit.GetLaCategorie().IdCategorie == -1)
            {
                req.Parameters.Add(new MySqlParameter("@produitIdCategorie", null));
            } else
            {
                req.Parameters.Add(new MySqlParameter("@produitIdCategorie", produit.GetLaCategorie().IdCategorie));
            }

            req.ExecuteNonQuery();

            return int.Parse(req.LastInsertedId.ToString());
        }

        public static void UpdateProduit(Produit produit)
        {
            String sql = "UPDATE produit SET libelle_produit = @produitLibelle, prix_unitaire_HT = @produitPrix, reference = @produitReference, quantiteProduit = @produitQuantite, description_produit = @produitDescription, id_categorie = @produitIdCategorie " +
                "WHERE id_produit = @produitId";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@produitLibelle", produit.LibelleProduit));
            req.Parameters.Add(new MySqlParameter("@produitPrix", produit.PrixUnitaireProduit));
            req.Parameters.Add(new MySqlParameter("@produitReference", produit.ReferenceProduit));
            req.Parameters.Add(new MySqlParameter("@produitQuantite", produit.QuantiteProduit));
            req.Parameters.Add(new MySqlParameter("@produitLDescription", produit.DescriptionProduit));

            if (produit.GetLaCategorie() == null || produit.GetLaCategorie().IdCategorie == 1)
            {
                req.Parameters.Add(new MySqlParameter("@produitIdCategorie", produit.GetLaCategorie().IdCategorie));
            } else
            {
                req.Parameters.Add(new MySqlParameter("@produitIdCategorie", produit.GetLaCategorie().IdCategorie));
            }

            req.Parameters.Add(new MySqlParameter("@produitId", produit.IdProduit));

            req.ExecuteNonQuery();
        }

        public static void SupprimerProduit(Produit produit)
        {
            String sql = "DELETE FROM produit WHERE id_produit = @produitId";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@produitId", produit.IdProduit));

            req.ExecuteNonQuery();
        }
    }
}
