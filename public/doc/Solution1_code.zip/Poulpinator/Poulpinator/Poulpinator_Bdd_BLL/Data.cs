﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Poulpinator_Bdd_BLL
{
    public static class Data
    {
        public static string UneChaineConnexionBDD { get; set; }
        public static MySqlConnection UneConnexionBDD { get; set; }
        public static String BDDConnStatut { get; set; }
        public static String BDDConnMsg { get; set; }

        public static void DbConnect()
        {
            //instancie l'objet de connection
            Data.UneConnexionBDD = new MySqlConnection(Data.UneChaineConnexionBDD);

            //tente de connecter le serveur
            try
            {
                //ouvre la connexion
                Data.UneConnexionBDD.Open();

                //affiche un message de réussite sur l'état de la connexion
                MessageBox.Show("Connexion à la base de données réussie. \n Etat de la connexion : " + Data.UneConnexionBDD.State, "Connexion à la base de données", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } catch(MySqlException uneSqlException)
            {
                MessageBox.Show("L'erreur suivante s'est produite : " + uneSqlException.Message + "\nMotif : " + uneSqlException.InnerException + "\nL'application va s'arrêter.", "Erreur de la connexion", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Application.Exit();
            } catch(Exception uneException)
            {
                MessageBox.Show("L'erreur suivante s'est produite : " + uneException.Message + "\nL'application va s'arrêter.", "Erreur de la connexion", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Application.Exit();
            }
        }

        public static void DbDisconnect()
        {
            //ferme la connexion à la base de données
            Data.UneConnexionBDD.Close();
            MessageBox.Show("Etat de la connexion : " + Data.UneConnexionBDD.State, "Connexion à la base de données", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
