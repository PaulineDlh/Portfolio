﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poulpinator_Classes_BLL;
using MySql.Data.MySqlClient;

namespace Poulpinator_Bdd_BLL
{
    public static class DbCommande
    {
        public static List<Commande> GetCommandes()
        {
            List<Commande> Commandes = new List<Commande>();

            String sql = "SELECT c.id_commande, c.date_commande, c.total_HT, c.frais_port_HT, " +
                "a.id_adresse, a.voie, a.complement, a.code_postal, a.ville, " +
                "cli.id_client, cli.nom, cli.prenom " +
                "FROM client as cli, commande as c LEFT JOIN adresse as a ON a.id_adresse = c.id_adresse " +
                "WHERE c.id_client = cli.id_client ";
                
            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            MySqlDataReader res = req.ExecuteReader();

            if (res.HasRows)
            {
                while (res.Read())
                {
                    Commandes.Add(
                        new Commande(
                            res.GetInt32("id_commande"),
                            res.GetDateTime("date_commande"),
                            res.GetDouble("total_HT"),
                            res.GetDouble("frais_port_HT"),
                            "Traitée",
                            new Adresse(1, "voie 1", "complement 1", "75014", "Paris"),
                            new Client(1, "Thierry", "Savary", 1)
                            )
                        );
                }
            }

            res.Close();

            return Commandes;
                        
        }

        public static List<ContenuCommande> GetContenuCommandes (Commande commande)
        {
            List<ContenuCommande> ContenuCommandes = new List<ContenuCommande>();

            String sql = "SELECT c.id_contenu_commande, c.id_produit, c.quantite_contenu, c.prix_unitaire_HT " +
                "FROM contenu_commande as c " +
                "WHERE c.id_commande = @commandeId";

            MySqlCommand req = new MySqlCommand(sql, Data.UneConnexionBDD);

            req.Parameters.Add(new MySqlParameter("@CommandeId", commande.IdCommande));

            MySqlDataReader res = req.ExecuteReader();

            if (res.HasRows)
            {
                while (res.Read())
                {
                    ContenuCommandes.Add(
                        new ContenuCommande(
                            res.GetInt32("id_contenu_commande"),    
                            res.GetDouble("prix_unitaire_HT"),
                            res.GetInt32("quantite_contenu"),
                            new Produit(1, "libelle produit", 15, 3, "ref"),
                            commande
                            )
                        );
                }
            }

            res.Close();

            return ContenuCommandes;
        }
    }
}
