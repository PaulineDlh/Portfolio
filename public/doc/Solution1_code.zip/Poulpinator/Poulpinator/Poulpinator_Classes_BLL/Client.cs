﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poulpinator_Classes_BLL
{
    public class Client
    {
        #region Attributs

        private int idClient;
        public int IdClient
        {
            get { return this.idClient; }
            set { this.idClient = value; }
        }
        private string prenomClient;
        public String PrenomClient
        {
            get { return this.prenomClient; }
            set { this.prenomClient = value; }
        }
        private string nomClient;
        public String NomClient
        {
            get { return this.nomClient; }
            set { this.nomClient = value; }
        }
        private int actif = 1;
        public int Actif
        {
            get { return this.actif; }
            set { this.actif = value; }
        }
        private List<Adresse> lesAdresses = new List<Adresse>();
        private List<Commande> lesCommandes = new List<Commande>();

        #endregion

        #region Constructeurs

        public Client() { }

        //constructeur surchargé prenant en paramètre tous les champs
        public Client(int pIdClient, string pPrenomClient, string pNomClient, int pActif)
        {
            this.idClient = pIdClient;
            this.prenomClient = pPrenomClient;
            this.nomClient = pNomClient;
            this.actif = pActif;
        }
        #endregion

        #region Accesseurs

        public int GetIdClient()
        {
            return this.idClient;
        }

        public void SetIdClient(int pIdClient)
        {
            this.idClient = pIdClient;
        }

        public string GetPrenomClient()
        {
            return this.prenomClient;
        }

        public void SetPrenomClient(string pPrenomClient)
        {
            this.prenomClient = pPrenomClient;
        }

        public string GetNomClient()
        {
            return this.nomClient;
        }

        public void SetNomClient(string pNomClient)
        {
            this.nomClient = pNomClient;
        }

        public int GetActif()
        {
            return this.actif;
        }

        public void SetActif(int pActif)
        {
            this.actif = pActif;
        }

        public List<Adresse> GetLesAdresses()
        {
            return this.lesAdresses;
        }

        public void SetLesAdresse(List<Adresse> pLesAdresses)
        {
            this.lesAdresses = pLesAdresses;
        }
        #endregion
    }
}
