﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poulpinator_Classes_BLL
{
    public class Adresse
    {
        #region Attributs

        private int idAdresse;
        public int IdAdresse
        {
            get { return this.idAdresse; }
            set { this.idAdresse = value; }
        }
        private string voie;
        public String Voie
        {
            get { return this.voie; }
            set { this.voie = value; }
        }
        private string complement;
        public String Complement
        {
            get { return this.complement; }
            set { this.complement = value; }
        }
        private string codePostal;
        public String CodePostal
        {
            get { return this.codePostal; }
            set { this.codePostal = value; }
        }
        private string ville;
        public String Ville
        {
            get { return this.ville; }
            set { this.ville = value; }
        }
        Client unClient;

        #endregion

        #region Constructeurs

        public Adresse() { }

        //constructeur surchargé prenant en paramètre tous les champs
        public Adresse(int pIdAdresse, string pVoie, string pComplement, string pCodePostal, string pVille, Client pUnClient)
        {
            this.idAdresse = pIdAdresse;
            this.voie = pVoie;
            this.complement = pComplement;
            this.codePostal = pCodePostal;
            this.ville = pVille;
            this.unClient = pUnClient;
        }

        //constructeur surchargé sans le client
        public Adresse(int pIdAdresse, string pVoie, string pComplement, string pCodePostal, string pVille)
        {
            this.idAdresse = pIdAdresse;
            this.voie = pVoie;
            this.complement = pComplement;
            this.codePostal = pCodePostal;
            this.ville = pVille;
        }
        #endregion

        #region Accesseurs

        public int GetIdAdresse()
        {
            return this.idAdresse;
        }

        public void SetIdAdresse(int pIdAdresse)
        {
            this.idAdresse = pIdAdresse;
        }

        public string GetVoie()
        {
            return this.voie;
        }

        public void SetVoie(string pVoie)
        {
            this.voie = pVoie;
        }

        public string GetComplement()
        {
            return this.complement;
        }

        public void SetComplement(string pComplement)
        {
            this.complement = pComplement;
        }

        public string GetCodePostal()
        {
            return this.codePostal;
        }

        public void SetCodePostal(string pCodePostal)
        {
            this.codePostal = pCodePostal;
        }

        public string GetVille()
        {
            return this.ville;
        }

        public void SetVille(string pVille)
        {
            this.ville = pVille;
        }

        public Client GetClient()
        {
            return this.unClient;
        }

        public void SetClient(Client pUnClient)
        {
            this.unClient = pUnClient;
        }

        #endregion
    }
}
