﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poulpinator_Classes_BLL
{
    public class Produit
    {
        #region Attributs

        private int idProduit;
        public int IdProduit
        {
            get { return this.idProduit; }
            set { this.idProduit = value; }
        }
        private string libelleProduit;
        public String LibelleProduit
        {
            get { return this.libelleProduit; }
            set { this.libelleProduit = value; }
        }
        private double prixUnitaireProduit;
        public double PrixUnitaireProduit
        {
            get { return this.prixUnitaireProduit; }
            set { this.prixUnitaireProduit = value; }
        }
        private int quantiteProduit;
        public int QuantiteProduit
        {
            get { return this.quantiteProduit; }
            set { this.quantiteProduit = value; }
        }
        private string referenceProduit;
        public String ReferenceProduit
        {
            get { return this.referenceProduit; }
            set { this.referenceProduit = value; }
        }
        private string descriptionProduit;
        public String DescriptionProduit
        {
            get { return this.descriptionProduit; }
            set { this.descriptionProduit = value; }
        }
        private Categorie laCategorie;
        public Categorie LaCategorie
        {
            get { return this.laCategorie; }
            set { this.laCategorie = value; }
        }
        public string ProduitLblCat
        {
            get { return this.laCategorie.LibelleCategorie; }
        }
        private List<ContenuCommande> lesContenuCommandes = new List<ContenuCommande>();

        #endregion

        #region Constructeurs

        public Produit() { }

        //constructeur surchargé prenant en paramètre tous les champs
        public Produit(int pIdProduit, string pLibelleProduit, double pPrixUnitaireProduit, int pQuantiteProduit, string pReferenceProduit, Categorie pLaCategorie)
        {
            this.idProduit = pIdProduit;
            this.libelleProduit = pLibelleProduit;
            this.prixUnitaireProduit = pPrixUnitaireProduit;
            this.quantiteProduit = pQuantiteProduit;
            this.referenceProduit = pReferenceProduit;
            this.laCategorie = pLaCategorie;
        }

        //constructeur surchargé sans la catégorie
        public Produit(int pIdProduit, string pLibelleProduit, double pPrixUnitaireProduit, int pQuantiteProduit, string pReferenceProduit)
        {
            this.idProduit = pIdProduit;
            this.libelleProduit = pLibelleProduit;
            this.prixUnitaireProduit = pPrixUnitaireProduit;
            this.quantiteProduit = pQuantiteProduit;
            this.referenceProduit = pReferenceProduit;
        }

        #endregion

        #region Accesseurs

        public int GetIdProduit()
        {
            return this.idProduit;
        }

        public void SetIDProduit(int pIdProduit)
        {
            this.idProduit = pIdProduit;
        }

        public string GetLibelleProduit()
        {
            return this.libelleProduit;
        }

        public void SetLibelleProduit(string pLibelleProduit)
        {
            this.libelleProduit = pLibelleProduit;
        }

        public double GetPrixUnitaireProduit()
        {
            return this.prixUnitaireProduit;
        }

        public void SetPrixUnitaireProduit(double pPrixUnitaireProduit)
        {
            this.prixUnitaireProduit = pPrixUnitaireProduit;
        }

        public int GetQuantiteProduit()
        {
            return this.quantiteProduit;
        }

        public void SetQuantiteProduit(int pQuantiteProduit)
        {
            this.quantiteProduit = pQuantiteProduit;
        }

        public string GetReferenceProduit()
        {
            return this.referenceProduit;
        }

        public void SetReferenceProduit(string pReferenceProduit)
        {
            this.referenceProduit = pReferenceProduit;
        }

        public string GetDescritionProduit()
        {
            return this.descriptionProduit;
        }

        public void SetDescriptionProduit(string pDescriptionProduit)
        {
            this.descriptionProduit = pDescriptionProduit;
        }

        public Categorie GetLaCategorie()
        {
            return this.laCategorie;
        }

        public void SetLaCategorie(Categorie pLaCategorie)
        {
            this.laCategorie = pLaCategorie;
        }

        #endregion
    }
}
