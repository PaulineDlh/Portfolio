﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poulpinator_Classes_BLL
{
    public class Commande
    {

        #region Attributs

        private int idCommande;
        public int IdCommande
        {
            get { return this.idCommande; }
            set { this.idCommande = value; }
        }
        private DateTime dateCommande;
        public DateTime DateCommande
        {
            get { return this.dateCommande; }
            set { this.dateCommande = value; }
        }
        private double prixTotalCommande;
        public double PrixTotalCommande
        {
            get { return this.prixTotalCommande; }
            set { this.prixTotalCommande = value; }
        }
        private double fraisPort;
        public double FraisPort
        {
            get { return this.fraisPort; }
            set { this.fraisPort = value; }
        }
        private string statutCommande = "statut commande";
        public string StatutCommande{
            get
            {
                return this.statutCommande;
            }

            set
            {
                this.statutCommande = value;
            }
        }
        private Client unClient;
        public Client UnClient
        {
            get { return this.unClient; }
            set { this.unClient = value; }
        }
        public int CmdIdClient
        {
            get { return this.unClient.IdClient; }
        }
        private Adresse uneAdresse;
        private List<ContenuCommande> lesContenuCommandes = new List<ContenuCommande>();

        #endregion

        #region Contructeurs

        public Commande() { }

        //constructeur surchargé prenant en paramètre tous les champs
        public Commande(int pIdCommande, DateTime pDateCommande, double pPrixTotalCommande, double pFraisPort, string pStatutCommande, Adresse pUneAdresse)
        {
            this.idCommande = pIdCommande;
            this.dateCommande = pDateCommande;
            this.prixTotalCommande = pPrixTotalCommande;
            this.fraisPort = pFraisPort;
            this.statutCommande = pStatutCommande;
            this.uneAdresse = pUneAdresse;
        }

        //constructeur surchargé prenant en paramètre tous les champs
        public Commande(int pIdCommande, DateTime pDateCommande, double pPrixTotalCommande, double pFraisPort, string pStatutCommande, Adresse pUneAdresse, Client pUnClient)
        {
            this.idCommande = pIdCommande;
            this.dateCommande = pDateCommande;
            this.prixTotalCommande = pPrixTotalCommande;
            this.fraisPort = pFraisPort;
            this.statutCommande = pStatutCommande;
            this.uneAdresse = pUneAdresse;
            this.unClient = pUnClient;
        }

        #endregion

        #region Accesseurs

        public int GetIdCommande()
        {
            return this.idCommande; 
        }

        public void SetIdCommande(int pIdCommande)
        {
            this.idCommande = pIdCommande;
        }

        public DateTime GetDateCommande()
        {
            return this.dateCommande;
        }

        public void SetDateCommande(DateTime pDateCommande)
        {
            this.dateCommande = pDateCommande;
        }

        public double GetPrixTotalCommande()
        {
            return this.prixTotalCommande;
        }

        public void SetPrixTotalCommande(double pPrixTotalCommande)
        {
            this.prixTotalCommande = pPrixTotalCommande;
        }

        public double GetFraisPort()
        {
            return this.fraisPort;
        }

        public void SetFraisPort(double pFraisPort)
        {
            this.fraisPort = pFraisPort;
        }

        public string GetStatutCommande()
        {
            return this.statutCommande;
        }

        public void SetStatutCommande(string pStatutCommande)
        {
            this.statutCommande = pStatutCommande;
        }

        public Client GetClient()
        {
            return this.unClient;
        }

        public void SetClient(Client pUnClient)
        {
            this.unClient = pUnClient;
        }

        public Adresse GetAdresse()
        {
            return this.uneAdresse;
        }

        public void SetAdresse(Adresse pUneAdresse)
        {
            this.uneAdresse = pUneAdresse;
        }

        public List<ContenuCommande> GetContenuCommandes()
        {
            return this.lesContenuCommandes;
        }

        public void SetContenuCommandes(List<ContenuCommande> pLesContenuCommandes)
        {
            this.lesContenuCommandes = pLesContenuCommandes;
        }
        #endregion
    }
}
