﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poulpinator_Classes_BLL
{
    public class ContenuCommande
    {
        #region Attributs

        private int idContenuCommande;
        public int IdContenuCommande
        {
            get { return this.idContenuCommande; }
            set { this.idContenuCommande = value; }
        }
        private double prixUnitaireContenuCommande;
        public double PrixUnitaireContenuCommande
        {
            get { return this.prixUnitaireContenuCommande; }
            set { this.prixUnitaireContenuCommande = value; }
        }
        private int quantiteContenuCommande;
        public int QuantiteContenuCommande
        {
            get { return this.quantiteContenuCommande; }
            set { this.quantiteContenuCommande = value; }
        }

        Commande uneCommande;
        Produit unProduit;
        public Produit UnProduit
        {
            get { return this.unProduit; }
            set { this.unProduit = value; }
        }
        public int ContenuCmdIdProduit
        {
            get { return this.unProduit.IdProduit; }
        }

        #endregion

        #region Constructeurs

        public ContenuCommande() { }

        //constructeur surchargé prenant tous les champs en paramètres
        public ContenuCommande(int pIdContenuCommande, double pPrixUnitaireContenuCommande, int pQuantiteContenuCommande)
        {
            this.idContenuCommande = pIdContenuCommande;
            this.prixUnitaireContenuCommande = pPrixUnitaireContenuCommande;
            this.quantiteContenuCommande = pQuantiteContenuCommande;
        }

        //constructeur surchargé prenant tous les champs en paramètres
        public ContenuCommande(int pIdContenuCommande, double pPrixUnitaireContenuCommande, int pQuantiteContenuCommande, Produit pUnProduit, Commande pUneCommande)
        {
            this.idContenuCommande = pIdContenuCommande;
            this.prixUnitaireContenuCommande = pPrixUnitaireContenuCommande;
            this.quantiteContenuCommande = pQuantiteContenuCommande;
            this.unProduit = pUnProduit;
            this.uneCommande = pUneCommande;
        }

        #endregion

        #region Accesseurs

        public int GetIdContenuCommande()
        {
            return this.idContenuCommande;
        }

        public void SetIdContenuCommande(int pIdContenuCommande)
        {
            this.idContenuCommande = pIdContenuCommande;
        }

        public double GetPrixUnitaireContenuCommande()
        {
            return this.prixUnitaireContenuCommande;
        }

        public void SetPrixUnitaireContenuCommande(double pPrixUnitaireContenuCommande)
        {
            this.prixUnitaireContenuCommande = pPrixUnitaireContenuCommande;
        }

        public int GetQuantiteContenuCommande()
        {
            return this.quantiteContenuCommande;
        }

        public void SetQuantiteContenuCommande(int pQuantiteContenuCommande)
        {
            this.quantiteContenuCommande = pQuantiteContenuCommande;
        }

        public Commande GetCommande()
        {
            return this.uneCommande;
        }

        public void SetCommande(Commande pUneCommande)
        {
            this.uneCommande = pUneCommande;
        }

        public Produit GetProduit()
        {
            return this.unProduit;
        }

        public void SetProduit(Produit pUnProduit)
        {
            this.unProduit = pUnProduit;
        }

        #endregion
    }
}
