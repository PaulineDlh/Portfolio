﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poulpinator_Classes_BLL
{
    public class Categorie
    {

        #region Attributs

        private int idCategorie;
        public int IdCategorie
        {
            get { return this.idCategorie; }
            set { this.idCategorie = value; }
        }
        private string libelleCategorie = "libellé cat";
        public string LibelleCategorie
        {
            get
            {
                return this.libelleCategorie;
            }

            set
            {
                this.libelleCategorie = value;
            }
        }
        private List<Produit> lesProduits = new List<Produit>();

        #endregion

        #region Constructeurs

        public Categorie() { }

        //constructeur surchargé prenant en paramètre tous les champs
        public Categorie(int pIdCategorie, string pLibelleCategorie)
        {
            this.idCategorie = pIdCategorie;
            this.libelleCategorie = pLibelleCategorie;
        }

        #endregion

        #region Accesseurs

        public int GetIdCategorie()
        {
            return this.idCategorie;
        }

        public void SetIdCategorie(int pIdCategorie)
        {
            this.idCategorie = pIdCategorie;
        }

        public string GetLibelleCategorie()
        {
            return this.libelleCategorie;
        }

        public void SetLibelleCategorie(string pLibelleCategorie)
        {
            this.libelleCategorie = pLibelleCategorie;
        }

        public List<Produit> GetProduit()
        {
            return this.lesProduits;
        }

        public void SetLesProduits(List<Produit> pLesProduits)
        {
            this.lesProduits = pLesProduits;
        }

        #endregion
    }
}
